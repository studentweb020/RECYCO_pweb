<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ItemOrder;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckoutController extends Controller
{
    public function index(Product $product)
    {
        return view('user.checkout', [
            'product' => $product
        ]);
    }

    public function do_checkout(Request $request, Product $product)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'address' => 'required|string|max:500',
            'payment_method' => 'required|string|max:255',
            'notes' => 'nullable|string|max:1000'
        ]);

        try {
            $user = Auth::user();
            $total = $product->price * $request->quantity;

            $order = Order::create([
                'user_id' => $user ? $user->id : null,
                'total' => $total,
                'name' => $request->name,
                'email' => $request->email,
                'address' => $request->address,
                'payment_method' => $request->payment_method,
                'notes' => $request->notes,
                'status' => 'pending'
            ]);

            $itemOrder = ItemOrder::create([
                'order_id' => $order->id,
                'product_id' => $product->id,
                'qty' => $request->quantity,
                'product_attributes' => json_encode($product),
            ]);

            session()->put('last_order', [
                'item_order' => [
                    $itemOrder
                ],
                'order' => $order,
                'timestamp' => now(),
            ]);

            return redirect()->route('checkout.thankyou');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Error processing order: ' . $e->getMessage()]);
        }
    }

    public function thankyou()
    {
        return view('user.thankyou', [
            'order' => session('last_order')
        ]);
    }
}
