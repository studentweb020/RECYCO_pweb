<div>
    <!-- Search and Filter Section -->
    <div class="search-filter-section">
        <div class="search-filter-form">
            <input type="text" 
                   wire:model.debounce.500ms="search"
                   class="search-input" 
                   placeholder="Cari nama produk atau deskripsi...">
            
            <select wire:model="sortBy" class="sort-select">
                <option value="created_at">Terbaru</option>
                <option value="name">Nama A-Z</option>
                <option value="price">Harga</option>
            </select>
            
            <select wire:model="sortOrder" class="sort-select">
                <option value="desc">Menurun</option>
                <option value="asc">Menaik</option>
            </select>
            
            @if($search)
            <button wire:click="resetFilters" class="btn-search" style="background-color: #dc3545;">
                Reset
            </button>
            @endif
        </div>
    </div>

    <!-- Loading Indicator -->
    <div wire:loading class="loading-indicator" style="text-align: center; padding: 20px;">
        <div style="display: inline-block; padding: 10px 20px; background: #f8f9fa; border-radius: 5px; color: #666;">
            <span>🔄 Memuat produk...</span>
        </div>
    </div>

    @if($search)
    <div style="margin: 15px 0; padding: 10px; background: #e8f5e8; border-radius: 5px;">
        <strong>Hasil pencarian untuk:</strong> "{{ $search }}"
        <span style="color: #666;">({{ $products->total() }} produk ditemukan)</span>
    </div>
    @endif

    <!-- Products Count -->
    <div class="products-header">
        <h2>Semua Produk Eco-Friendly</h2>
        <div class="products-count">
            Menampilkan {{ $products->count() }} dari {{ $products->total() }} produk
        </div>
    </div>

    <!-- Products Grid -->
    <div class="product-grid" wire:loading.class="opacity-50">
        @if($products->count() > 0)
            @foreach($products as $product)
            <div class="product-card">
                <div class="product-image">
                    <img src="{{ $product->image }}" alt="{{ $product->name }}" loading="lazy">
                </div>
                <div class="product-info">
                    <h4>{{ $product->name }}</h4>
                    <p style="color: #666; font-size: 14px; margin: 8px 0;">
                        {{ Str::limit($product->description, 80) }}
                    </p>
                    <p class="price">Rp{{ number_format($product->price, 0, ',', '.') }}</p>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <a href="{{ route('checkout.index', $product->id) }}" 
                           class="btn-checkout" 
                           style="display: block; flex: 1; color: white; text-align: center;">
                           Beli
                        </a>
                        <button class="btn-checkout btn-add-cart" 
                                data-product="{{ json_encode($product) }}"
                                style="background-color: #312e8b;">
                            Cart
                        </button>
                    </div>
                </div>
            </div>
            @endforeach
        @else
            <div class="no-products">
                @if($search)
                    <p>Tidak ada produk yang ditemukan untuk pencarian "{{ $search }}"</p>
                    <button wire:click="resetFilters" class="btn-checkout">Lihat Semua Produk</button>
                @else
                    <p>Belum ada produk yang tersedia saat ini.</p>
                @endif
            </div>
        @endif
    </div>

    <!-- Pagination -->
    @if($products->hasPages())
    <div class="pagination-wrapper" style="margin: 30px 0;">
        {{ $products->links() }}
    </div>
    @endif

    <style>
        .loading-indicator {
            transition: all 0.3s ease;
        }
        
        .opacity-50 {
            opacity: 0.6;
            transition: opacity 0.3s ease;
        }
        
        .search-filter-section {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .search-filter-form {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }

        .search-input {
            flex: 1;
            min-width: 250px;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        .search-input:focus {
            outline: none;
            border-color: #2e8b57;
        }

        .sort-select {
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            background: white;
            transition: border-color 0.3s ease;
        }

        .sort-select:focus {
            outline: none;
            border-color: #2e8b57;
        }

        .btn-search {
            background-color: #2e8b57;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-search:hover {
            background-color: #3cb371;
        }

        .btn-checkout {
            background-color: #2e8b57;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 15px;
            text-decoration: none;
        }

        .btn-checkout:hover {
            background-color: #3cb371;
            color: white;
        }

        .products-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
        }

        .products-count {
            color: #666;
            font-size: 16px;
        }

        .no-products {
            text-align: center;
            padding: 50px;
            color: #666;
            font-size: 18px;
        }

        /* Pagination Styling */
        .pagination-wrapper {
            display: flex;
            justify-content: center;
        }

        .pagination {
            display: flex;
            gap: 5px;
        }

        .pagination .page-link {
            padding: 10px 15px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #333;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .pagination .page-link:hover {
            background-color: #2e8b57;
            color: white;
            border-color: #2e8b57;
        }

        .pagination .page-item.active .page-link {
            background-color: #2e8b57;
            color: white;
            border-color: #2e8b57;
        }

        .pagination .page-item.disabled .page-link {
            color: #ccc;
            cursor: not-allowed;
        }

        @media (max-width: 768px) {
            .search-filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-input {
                min-width: auto;
            }
            
            .products-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
</div>