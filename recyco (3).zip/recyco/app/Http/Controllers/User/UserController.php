<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index()
    {
        return view('user.index');
    }

    public function menu()
    {
        $products = [
            [
                'id' => 1,
                'name' => 'Keranjang Mini Handmade Quilling',
                'price' => 55000,
                'image' => 'keranjang_mini.png'
            ],
            [
                'id' => 2,
                'name' => 'Hiasan Gantung Konus Pelangi Daur Ulang',
                'price' => 100000,
                'image' => 'hiasan_gantung.png'
            ],
            [
                'id' => 3,
                'name' => 'Keranjang Multifungsi Handmade dari Koran',
                'price' => 85000,
                'image' => 'keranjang_koran.png'
            ],
            [
                'id' => 4,
                'name' => 'Tempat Sampah Tutup Botol Motif Bunga',
                'price' => 120000,
                'image' => 'tempat_sampah_botol.png'
            ],
            [
                'id' => 5,
                'name' => 'Tempat Sampah Pilah Galon Warna-warni',
                'price' => 200000,
                'image' => 'tempat_sampah_galon.png'
            ],
            [
                'id' => 6,
                'name' => 'Cermin Daur Ulang dari Sendok Plastik',
                'price' => 95000,
                'image' => 'cermin_sendok.png'
            ],
            [
                'id' => 7,
                'name' => 'Hiasan Dinding Motif dari Tutup Botol',
                'price' => 80000,
                'image' => 'hiasan_dingding_tutup.png'
            ],
            [
                'id' => 8,
                'name' => 'Tas Unik dari Tutup Botol Daur Ulang',
                'price' => 40000,
                'image' => 'tas_tutup.png'
            ],
            [
                'id' => 9,  // Diubah dari ID duplikat 8 menjadi 9 agar unik
                'name' => 'Tempat Sampah Hias dari Ban Bekas',
                'price' => 75000,
                'image' => 'tempat_sampah.png'
            ]
        ];

        // return view('welcome');
        $navItems = [
            ['icon' => '🛒', 'name' => 'Beli produk', 'link' => '#'],      // Menu beli produk
            ['icon' => '🤝', 'name' => 'Jual Produk', 'link' => '#'],       // Menu jual produk
            ['icon' => '📋', 'name' => 'Pesanan Saya', 'link' => route('order')], // Menu melihat pesanan
            ['icon' => '💡', 'name' => 'Tips', 'link' => '#'],             // Menu tips
            ['icon' => '👥', 'name' => 'Komunitas', 'link' => '#']          // Menu komunitas
        ];

        return view('user.menu', [
            'navItems' => $navItems,
            'products' => $products,
        ]);
    }

    public function checkout(Product $product)
    {
        return view('user.checkout', [
            'product' => $product
        ]);
    }

    public function do_checkout(Request $request, Product $product)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'address' => 'required|string|max:500',
            'payment_method' => 'required|string|max:255',
            'notes' => 'nullable|string|max:1000'
        ]);

        try {
            $user = Auth::user();
            $total = $product->price * $request->quantity;

            $order = Order::create([
                'product_id' => $product->id,
                'user_id' => $user ? $user->id : null,
                'quantity' => $request->quantity,
                'total_price' => $total,
                'name' => $request->name,
                'email' => $request->email,
                'address' => $request->address,
                'payment_method' => $request->payment_method,
                'notes' => $request->notes,
                'status' => 'pending'
            ]);

            session()->put('last_order', [
                'product' => $product,
                'order' => $order,
                'timestamp' => now(),
            ]);

            return redirect()->route('thankyou');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Error processing order: ' . $e->getMessage()]);
        }
    }

    public function thankyou()
    {
        return view('user.thankyou', [
            'order' => session('last_order')
        ]);
    }

    public function order()
    {
        $orders = Order::with('product')->latest()->get();
        return view('user.order', [
            'orders' => $orders,
        ]);
    }

    public function update_order(Request $request, Order $order)
    {
        $request->validate([
            'address' => 'required|string|max:500',
            'payment_method' => 'required|string|max:255'
        ]);

        $order->update($request->only('address', 'payment_method'));

        return redirect()->route('order')
            ->with('success', 'Order updated successfully');
    }

    public function delete_order(Order $order)
    {
        $order->delete();

        return redirect()->route('order')
            ->with('success', 'Order deleted successfully');
    }

    public function cancel_order(Order $order)
{
    try {
        $allowedStatuses = ['pending', 'processing'];

        if (!in_array($order->status, $allowedStatuses)) {
            return redirect()->back()->withErrors([
                'error' => 'Pesanan tidak dapat dibatalkan (mungkin sudah dikirim/diterima)'
            ]);
        }

        $order->update(['status' => 'cancelled']);

        return redirect()->route('order')
            ->with('success', 'Pesanan berhasil dibatalkan');

    } catch (\Exception $e) {
        return redirect()->back()->withErrors([
            'error' => 'Error membatalkan pesanan: ' . $e->getMessage()
        ]);
    }
}
}
