<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\ItemOrder;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function index()
    {
        return view('user.cart');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'address' => 'required|string|max:500',
            'payment_method' => 'required|string|max:255',
            'notes' => 'nullable|string|max:1000',

            'product' => 'required|array',
            'product.*.id' => 'required|integer|exists:products,id',
            'product.*.qty' => 'required|integer|min:1',
        ]);

        $user = Auth::user();

        $order = Order::create([
            'user_id' => $user ? $user->id : null,
            'total' => 0,
            'name' => $request->name,
            'email' => $request->email,
            'address' => $request->address,
            'payment_method' => $request->payment_method,
            'notes' => $request->notes,
            'status' => 'pending'
        ]);

        $total = 0;
        $itemOrders = [];

        foreach ($validated['product'] as $item) {
            $product = Product::find($item['id']);
            $total += $product->price * $item['qty'];

            $itemOrder = ItemOrder::create([
                'order_id' => $order->id,
                'product_id' => $product->id,
                'qty' => $item['qty'],
                'product_attributes' => json_encode($product),
            ]);

            $itemOrders[] = $itemOrder;
        }

        $order->update(['total' => $total]);

        session()->put('last_order', [
            'item_order' => $itemOrders,
            'order' => $order,
            'timestamp' => now(),
        ]);

        return redirect()->route('checkout.thankyou');
    }
}
