<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Komunitas - Recyco</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }

        .komunitas-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            min-height: 100vh;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        /* Header Styles */
        .komunitas-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: white;
            border-bottom: 1px solid #e0e0e0;
        }

        .komunitas-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .komunitas-logo-img {
            width: 30px;
            height: 30px;
        }

        .komunitas-brand {
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }

        .komunitas-nav {
            display: flex;
            gap: 15px;
        }

        .komunitas-icon-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .komunitas-icon-btn:hover {
            background-color: #f0f0f0;
        }

        .komunitas-bell,
        .komunitas-cart,
        .komunitas-profile {
            font-size: 18px;
        }

        /* Title Section */
        .komunitas-title-section {
            background: linear-gradient(135deg, #7dd3a0, #5bc97d);
            padding: 30px 25px;
            text-align: center;
        }

        .komunitas-title {
            color: white;
            font-size: 28px;
            font-weight: bold;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        /* Chat Content */
        .komunitas-content {
            background: #f8fffe;
            height: calc(100vh - 160px);
            display: flex;
            flex-direction: column;
        }

        .komunitas-chat-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .komunitas-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        /* Message Styles */
        .komunitas-message {
            display: flex;
            max-width: 80%;
        }

        .komunitas-message-left {
            align-self: flex-start;
        }

        .komunitas-message-right {
            align-self: flex-end;
        }

        .komunitas-message-bubble {
            background: #c8e6c9;
            padding: 12px 16px;
            border-radius: 18px;
            position: relative;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .komunitas-message-right .komunitas-message-bubble {
            background: #e8f5e8;
            border-bottom-right-radius: 4px;
        }

        .komunitas-message-left .komunitas-message-bubble {
            border-bottom-left-radius: 4px;
        }

        .komunitas-message-header {
            margin-bottom: 5px;
        }

        .komunitas-sender {
            font-weight: 600;
            font-size: 13px;
            color: #2d5016;
        }

        .komunitas-message-text {
            font-size: 14px;
            line-height: 1.4;
            color: #2d5016;
            margin-bottom: 8px;
        }

        .komunitas-message-time {
            font-size: 11px;
            color: #5a8a3a;
            float: right;
            margin-top: 5px;
        }

        /* Input Area */
        .komunitas-input-area {
            padding: 15px 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
        }

        .komunitas-input-container {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #f5f5f5;
            border-radius: 25px;
            padding: 8px 15px;
        }

        .komunitas-attachment-btn {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 18px;
            padding: 5px;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .komunitas-attachment-btn:hover {
            background-color: #e0e0e0;
        }

        .komunitas-input {
            flex: 1;
            border: none;
            background: none;
            padding: 8px 0;
            font-size: 14pxქ

System: 14px;
            outline: none;
            color: #333;
        }

        .komunitas-input::placeholder {
            color: #999;
        }

        .komunitas-send-btn {
            background: linear-gradient(135deg, #7dd3a0, #5bc97d);
            border: none;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .komunitas-send-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 2px 8px rgba(125, 211, 160, 0.4);
        }

        .komunitas-send-icon {
            color: white;
            font-size: 16px;
            font-weight: bold;
        }

        /* Responsive Design for Komunitas */
        @media (max-width: 768px) {
            .komunitas-container {
                max-width: 100%;
            }
            
            .komunitas-header {
                padding: 12px 20px;
            }
            
            .komunitas-title-section {
                padding: 25px 20px;
            }
            
            .komunitas-title {
                font-size: 24px;
            }
            
            .komunitas-content {
                height: calc(100vh - 140px);
            }
            
            .komunitas-messages {
                padding: 15px;
                gap: 12px;
            }
            
            .komunitas-message {
                max-width: 90%;
            }
            
            .komunitas-message-bubble {
                padding: 10px 14px;
            }
            
            .komunitas-message-text {
                font-size: 13px;
            }
            
            .komunitas-input-area {
                padding: 12px 15px;
            }
            
            .komunitas-input-container {
                padding: 6px 12px;
            }
            
            .komunitas-send-btn {
                width: 32px;
                height: 32px;
            }
        }
    </style>
</head>
<body>
    <div class="komunitas-container">
        <!-- Header -->
        <header class="komunitas-header">
            <div class="komunitas-logo">
                <img src="<?php echo e(asset('dist/logo.png')); ?>" alt="Recyco" class="komunitas-logo-img">
                <span class="komunitas-brand">Recyco</span>
            </div>
            <div class="komunitas-nav">
                <button class="komunitas-icon-btn">
                    <span class="komunitas-bell">🔔</span>
                </button>
                <button class="komunitas-icon-btn">
                    <span class="komunitas-cart">🛒</span>
                </button>
                <button class="komunitas-icon-btn">
                    <span class="komunitas-profile">👤</span>
                </button>
            </div>
        </header>

        <!-- Title Section -->
        <div class="komunitas-title-section">
            <h1 class="komunitas-title">Komunitas</h1>
        </div>

        <!-- Chat Content -->
        <div class="komunitas-content">
            <div class="komunitas-chat-container">
                <!-- Chat Messages -->
                <div class="komunitas-messages">
                    <!-- Message 1 - Rahma -->
                    <div class="komunitas-message komunitas-message-left">
                        <div class="komunitas-message-bubble">
                            <div class="komunitas-message-header">
                                <span class="komunitas-sender">Rahma</span>
                            </div>
                            <p class="komunitas-message-text">Aku baru mulai memilah sampah organik dan non-organik di rumah. Dengan bantuan fitur edukasi di RECYCO, aku jadi tahu langkah-langkah praktis untuk mengubah sampah organik menjadi kompos.</p>
                            <span class="komunitas-message-time">08:05 PM</span>
                        </div>
                    </div>

                    <!-- Message 2 - Bagus -->
                    <div class="komunitas-message komunitas-message-left">
                        <div class="komunitas-message-bubble">
                            <div class="komunitas-message-header">
                                <span class="komunitas-sender">Bagus</span>
                            </div>
                            <p class="komunitas-message-text">Wah, menarik! Aku juga mau mendaur ulang sendiri, tapi masih bingung mulai dari mana. Aku lihat ada banyak tutorial dan tips tentang daur ulang. Mungkin dimulai dengan yang sederhana dulu, seperti memilah sampah.</p>
                            <span class="komunitas-message-time">08:10 PM</span>
                        </div>
                    </div>

                    <!-- Message 3 - Aldi -->
                    <div class="komunitas-message komunitas-message-right">
                        <div class="komunitas-message-bubble">
                            <div class="komunitas-message-header">
                                <span class="komunitas-sender">Aldi</span>
                            </div>
                            <p class="komunitas-message-text">Aku lagi mikirin gimana caranya kita bisa meningkatkan kesadaran tentang daur ulang dan menjaga lingkungan. Ada ide kreatif apa untuk program daur ulang di lingkungan kita?</p>
                            <span class="komunitas-message-time">08:00 PM</span>
                        </div>
                    </div>

                    <!-- Message 4 - Indah -->
                    <div class="komunitas-message komunitas-message-left">
                        <div class="komunitas-message-bubble">
                            <div class="komunitas-message-header">
                                <span class="komunitas-sender">Indah</span>
                            </div>
                            <p class="komunitas-message-text">Selain itu, ada juga forum komunitas dimana warga bisa saling berbagi pengalaman dan inspirasi untuk mendaur ulang sampah di lingkungan masing-masing.</p>
                            <span class="komunitas-message-time">08:12 PM</span>
                        </div>
                    </div>

                    <!-- Message 5 - Putra -->
                    <div class="komunitas-message komunitas-message-left">
                        <div class="komunitas-message-bubble">
                            <div class="komunitas-message-header">
                                <span class="komunitas-sender">Putra</span>
                            </div>
                            <p class="komunitas-message-text">Setelah kita mendaur ulang sampah dan menghasilkan produk baru, RECYCO memungkinkan kita untuk menjual produk daur ulang. Jadi kita juga bisa membuat peluang usaha kecil-kecilan.</p>
                            <span class="komunitas-message-time">08:13 PM</span>
                        </div>
                    </div>
                </div>

                <!-- Input Area -->
                <div class="komunitas-input-area">
                    <div class="komunitas-input-container">
                        <button class="komunitas-attachment-btn">📎</button>
                        <input type="text" class="komunitas-input" placeholder="Mulai percakapan di sini...">
                        <button class="komunitas-send-btn">
                            <span class="komunitas-send-icon">➤</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\andre\recyco\resources\views/user/komunitas.blade.php ENDPATH**/ ?>