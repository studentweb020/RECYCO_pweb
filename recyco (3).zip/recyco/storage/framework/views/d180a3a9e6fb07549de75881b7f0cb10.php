<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - <?php // echo $selected_product['name'];
    ?> | Recyco</title>
    <link rel="stylesheet" href="<?php echo e(asset('dist/menu.css')); ?>">
    <style>
        .checkout-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }

        .product-section {
            flex: 1;
            min-width: 300px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .product-section:hover {
            transform: translateY(-5px);
        }

        .product-image-large {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .checkout-form {
            flex: 1;
            min-width: 300px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            height: 100px;
            resize: vertical;
        }

        .price-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .price-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .total-price {
            font-size: 20px;
            font-weight: bold;
            color: #2e8b57;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
        }

        .btn-checkout {
            background-color: #2e8b57;
            color: white;
            border: none;
            padding: 12px 20px;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        .btn-checkout:hover {
            background-color: #3cb371;
        }

        .quantity-selector {
            display: flex;
            align-items: center;
            margin: 15px 0;
        }

        .quantity-btn {
            background: #f0f0f0;
            border: none;
            width: 30px;
            height: 30px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
            margin: 0 10px;
            height: 30px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        @media (max-width: 768px) {
            .checkout-container {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <img src="<?php echo e(asset('dist/logo.png')); ?>" alt="Recyco" class="logo-image">
            <span>Recyco</span>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Cari produk eco-friendly...">
        </div>
        <div class="nav-icons">
            <div class="icon">🔔</div>
            <a href="<?php echo e(route('cart.index')); ?>">
                    🛒
                </a>
            <div class="icon">👤</div>
        </div>
    </header>

    <div class="checkout-container">
        <div class="product-section">
            <h2><?php echo e($product->name); ?></h2>
            <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="product-image-large">
            <p><?php echo e($product->description); ?></p>
            <div class="price-section">
                <div class="price-row">
                    <span>Harga Satuan:</span>
                    <span>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>

        <form class="checkout-form" method="POST" action="<?php echo e(route('checkout.do_checkout', $product->id)); ?>">
            <?php echo csrf_field(); ?>
            <h2>Informasi Pembelian</h2>

            <div class="form-group">
                <label for="quantity">Jumlah:</label>
                <div class="quantity-selector">
                    <button type="button" class="quantity-btn" id="decrease-qty">-</button>
                    <input type="number" id="quantity" name="quantity" class="quantity-input" value="1"
                        min="1">
                    <button type="button" class="quantity-btn" id="increase-qty">+</button>
                </div>
            </div>

            <div class="form-group">
                <label for="name">Nama Lengkap:</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="address">Alamat Pengiriman:</label>
                <textarea id="address" name="address" required></textarea>
            </div>

            <div class="form-group">
                <label for="payment_method">Metode Pembayaran:</label>
                <select id="payment_method" name="payment_method" required>
                    <option value="">Pilih metode pembayaran</option>
                    <option value="bank_transfer">Transfer Bank</option>
                    <option value="credit_card">Kartu Kredit</option>
                    <option value="e_wallet">E-Wallet (OVO, GoPay, Dana)</option>
                    <option value="cod">COD (Bayar di Tempat)</option>
                </select>
            </div>

            <div class="form-group">
                <label for="notes">Catatan (Opsional):</label>
                <textarea id="notes" name="notes"></textarea>
            </div>

            <div class="price-section">
                <div class="price-row">
                    <span>Subtotal:</span>
                    <span id="subtotal">Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                </div>
                <div class="price-row">
                    <span>Ongkos Kirim:</span>
                    <span>Rp15.000</span>
                </div>
                <div class="price-row total-price">
                    <span>Total Pembayaran:</span>
                    <span id="total-price">Rp<?php echo e(number_format($product->price + 15000, 0, ',', '.')); ?></span>
                </div>
            </div>

            <button type="submit" class="btn-checkout">Proses Pembayaran</button>
        </form>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Recyco - Marketplace Produk Eco-friendly</p>
        </div>
    </footer>

    <script>
        // Quantity selector functionality
        const decreaseBtn = document.getElementById('decrease-qty');
        const increaseBtn = document.getElementById('increase-qty');
        const quantityInput = document.getElementById('quantity');
        const subtotalElement = document.getElementById('subtotal');
        const totalPriceElement = document.getElementById('total-price');

        const productPrice = <?php echo e($product['price']); ?>;
        const shippingCost = 15000;

        function updatePrices() {
            const quantity = parseInt(quantityInput.value);
            const subtotal = productPrice * quantity;
            const total = subtotal + shippingCost;

            subtotalElement.textContent = 'Rp' + subtotal.toLocaleString('id-ID');
            totalPriceElement.textContent = 'Rp' + total.toLocaleString('id-ID');
        }

        decreaseBtn.addEventListener('click', function() {
            let value = parseInt(quantityInput.value);
            if (value > 1) {
                value--;
                quantityInput.value = value;
                updatePrices();
            }
        });

        increaseBtn.addEventListener('click', function() {
            let value = parseInt(quantityInput.value);
            value++;
            quantityInput.value = value;
            updatePrices();
        });

        quantityInput.addEventListener('change', function() {
            let value = parseInt(quantityInput.value);
            if (isNaN(value) || value < 1) {
                quantityInput.value = 1;
            }
            updatePrices();
        });

        // Form submission animation
        const form = document.querySelector('.checkout-form');
        form.addEventListener('submit', function(e) {
            e.preventDefault();

            // Simple form validation
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = 'red';
                    isValid = false;
                } else {
                    field.style.borderColor = '#ddd';
                }
            });

            if (isValid) {
                // Show loading effect
                const submitBtn = form.querySelector('button[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.textContent = 'Memproses...';

                // Simulate processing delay
                setTimeout(() => {
                    form.submit();
                }, 1500);
            } else {
                alert('Silakan lengkapi semua field yang wajib diisi!');
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\andre\recyco\resources\views/user/checkout.blade.php ENDPATH**/ ?>