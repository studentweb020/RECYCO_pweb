<?php

namespace App\Livewire\User;

use App\Models\Product;
use Livewire\Component;
use Livewire\WithPagination;

class ProductList extends Component
{
    use WithPagination;

    public $search = '';
    public $sortBy = 'created_at';
    public $sortOrder = 'desc';
    public $perPage = 12;

    protected $paginationTheme = 'bootstrap-4';

    protected $queryString = [
        'search' => ['except' => ''],
        'sortBy' => ['except' => 'created_at'],
        'sortOrder' => ['except' => 'desc']
    ];

    // Event listeners untuk manual trigger
    protected $listeners = [
        'sortByChanged' => 'handleSortByChanged',
        'sortOrderChanged' => 'handleSortOrderChanged'
    ];

    public function mount()
    {
        \Log::info('ProductList mounted', [
            'search' => $this->search,
            'sortBy' => $this->sortBy,
            'sortOrder' => $this->sortOrder
        ]);
        
        $this->search = request()->get('search', '');
        $this->sortBy = request()->get('sort_by', 'created_at');
        $this->sortOrder = request()->get('sort_order', 'desc');
    }

    public function handleSortByChanged($value)
    {
        \Log::info('Manual sortBy changed', ['value' => $value]);
        $this->sortBy = $value;
        $this->resetPage();
    }

    public function handleSortOrderChanged($value)
    {
        \Log::info('Manual sortOrder changed', ['value' => $value]);
        $this->sortOrder = $value;
        $this->resetPage();
    }

    public function updatingSearch()
    {
        \Log::info('Search updating', ['search' => $this->search]);
        $this->resetPage();
    }

    public function updatedSortBy()
    {
        \Log::info('SortBy updated via wire:model', ['sortBy' => $this->sortBy]);
        $this->resetPage();
    }

    public function updatedSortOrder()
    {
        \Log::info('SortOrder updated via wire:model', ['sortOrder' => $this->sortOrder]);
        $this->resetPage();
    }

    public function resetFilters()
    {
        $this->search = '';
        $this->sortBy = 'created_at';
        $this->sortOrder = 'desc';
        $this->resetPage();
    }

    public function render()
    {
        \Log::info('ProductList rendering', [
            'search' => $this->search,
            'sortBy' => $this->sortBy,
            'sortOrder' => $this->sortOrder
        ]);

        // Validasi sort parameters
        $allowedSortBy = ['created_at', 'name', 'price', 'updated_at'];
        $allowedSortOrder = ['asc', 'desc'];
        
        if (!in_array($this->sortBy, $allowedSortBy)) {
            $this->sortBy = 'created_at';
        }
        
        if (!in_array($this->sortOrder, $allowedSortOrder)) {
            $this->sortOrder = 'desc';
        }

        // Query dasar untuk produk yang aktif
        $query = Product::where('status', '1');

        // Filter berdasarkan pencarian jika ada
        if ($this->search) {
            $query->where(function($q) {
                $q->where('name', 'like', '%' . $this->search . '%')
                  ->orWhere('description', 'like', '%' . $this->search . '%');
            });
        }

        // Sorting
        $query->orderBy($this->sortBy, $this->sortOrder);

        // Debug: Log query SQL
        \Log::info('SQL Query', [
            'sql' => $query->toSql(),
            'bindings' => $query->getBindings(),
            'sortBy' => $this->sortBy,
            'sortOrder' => $this->sortOrder
        ]);

        // Pagination
        $products = $query->paginate($this->perPage);

        // Debug: Log produk yang didapat
        $productNames = $products->pluck('name')->toArray();
        \Log::info('Products retrieved', [
            'count' => $products->count(),
            'total' => $products->total(),
            'product_names' => $productNames,
            'sorting' => $this->sortBy . ' ' . $this->sortOrder
        ]);

        return view('livewire.user.product-list', [
            'products' => $products
        ]);
    }
}