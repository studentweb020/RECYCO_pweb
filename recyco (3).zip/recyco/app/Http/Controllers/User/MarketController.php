<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class MarketController extends Controller
{
    public function index()
    {
        $navItems = [
            ['icon' => '🛒', 'name' => 'Beli produk', 'link' => route('market.products')],
            ['icon' => '🤝', 'name' => 'Jual Produk', 'link' => route('market.switch_to_seller')],
            ['icon' => '📋', 'name' => 'Pesanan Saya', 'link' => route('order.index')],
            ['icon' => '💡', 'name' => 'Tips', 'link' => route('tips.index')],
            ['icon' => '👥', 'name' => 'Komunitas', 'link' => route('komunitas.index')]
        ];

        // Tampilkan hanya beberapa produk featured untuk homepage
        $products = Product::where('status', '1')
            ->latest()
            ->take(8) // Batasi hanya 8 produk untuk homepage
            ->get();

        return view('user.market', [
            'navItems' => $navItems,
            'products' => $products,
        ]);
    }

    public function products(Request $request)
    {
        // Sekarang menggunakan Livewire, jadi method ini hanya menampilkan view
        return view('user.market.products');
    }

    public function show(Product $product)
    {
        // Pastikan produk aktif
        if ($product->status != '1') {
            abort(404, 'Produk tidak tersedia atau telah dihapus.');
        }

        // Ambil produk terkait (berdasarkan rentang harga, kecuali produk ini)
        $relatedProducts = Product::where('status', '1')
            ->where('id', '!=', $product->id)
            ->whereBetween('price', [$product->price * 0.8, $product->price * 1.2]) // ±20% price range
            ->latest()
            ->take(4)
            ->get();

        // Jika tidak ada produk terkait berdasarkan harga, ambil produk terbaru
        if ($relatedProducts->count() < 4) {
            $additionalProducts = Product::where('status', '1')
                ->where('id', '!=', $product->id)
                ->whereNotIn('id', $relatedProducts->pluck('id'))
                ->latest()
                ->take(4 - $relatedProducts->count())
                ->get();
            
            $relatedProducts = $relatedProducts->merge($additionalProducts);
        }

        return view('user.products', [
            'product' => $product,
            'relatedProducts' => $relatedProducts,
        ]);
    }

    public function switchToSeller(Request $request)
    {
        // Logout user dari guard 'web' (user)
        auth()->guard('web')->logout();
        
        // Invalidate session
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        // Redirect ke halaman login seller
        return redirect()->route('seller.login')
            ->with('info', 'Silakan login sebagai seller untuk mulai berjualan.');
    }
}