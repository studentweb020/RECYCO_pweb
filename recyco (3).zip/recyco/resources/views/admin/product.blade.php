<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Recyco - Produk</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        /* Layout */
        .container {
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid #3c546d;
        }

        .sidebar-header img {
            width: 40px;
            margin-right: 10px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
            cursor: pointer;
            color: white;
            text-decoration: none;
        }

        .menu-item.active {
            background-color: #3c546d;
            border-left: 4px solid #4CAF50;
        }

        .menu-item:hover {
            background-color: #3c546d;
        }

        .menu-item i {
            margin-right: 10px;
            font-size: 18px;
        }

        .admin-info {
            padding: 20px;
            border-top: 1px solid #3c546d;
            position: absolute;
            bottom: 20px;
            width: 100%;
        }

        .admin-name {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .logout-btn {
            color: #e74c3c;
            margin-top: 10px;
            display: inline-block;
            text-decoration: none;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .page-header h1 {
            font-size: 24px;
            color: #333;
        }

        .date {
            color: #666;
            font-size: 14px;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
            border-top: 3px solid #3498db;
        }

        .stat-card h3 {
            font-size: 14px;
            color: #777;
            margin-bottom: 10px;
        }

        .stat-card .count {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }

        .stat-card:nth-child(1) {
            border-top-color: #3498db;
        }

        .stat-card:nth-child(2) {
            border-top-color: #f39c12;
        }

        .stat-card:nth-child(3) {
            border-top-color: #2ecc71;
        }

        .stat-card:nth-child(4) {
            border-top-color: #e74c3c;
        }

        /* Filters */
        .filters {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }

        .filter-tabs {
            display: flex;
            gap: 10px;
        }

        .filter-tab {
            padding: 8px 16px;
            border-radius: 20px;
            background-color: #eee;
            cursor: pointer;
            text-decoration: none;
            color: #555;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .filter-tab.active {
            background-color: #4CAF50;
            color: white;
        }

        .filter-tab:hover {
            background-color: #ddd;
        }

        .filter-tab.active:hover {
            background-color: #45a049;
        }

        .search-box {
            display: flex;
            gap: 10px;
        }

        .search-box input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 250px;
            font-size: 14px;
        }

        .search-box button {
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .search-box button:hover {
            background-color: #2980b9;
        }

        /* Products Grid */
        .products-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }

        .product-card {
            border: 1px solid #eee;
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background: white;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .product-image {
            width: 100%;
            height: 200px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #adb5bd;
            font-size: 14px;
        }

        .product-info {
            padding: 15px;
        }

        .product-name {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .product-price {
            font-size: 18px;
            font-weight: bold;
            color: #2ecc71;
            margin-bottom: 8px;
        }

        .product-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
            margin-bottom: 10px;
        }

        .status-pending {
            background-color: #fff3e0;
            color: #ff9800;
        }

        .status-approved {
            background-color: #e8f5e9;
            color: #4caf50;
        }

        .status-rejected {
            background-color: #ffebee;
            color: #f44336;
        }

        .product-actions {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-approve {
            background-color: #4caf50;
            color: white;
        }

        .btn-approve:hover {
            background-color: #45a049;
        }

        .btn-reject {
            background-color: #f44336;
            color: white;
        }

        .btn-reject:hover {
            background-color: #da190b;
        }

        .btn-edit {
            background-color: #2196f3;
            color: white;
        }

        .btn-edit:hover {
            background-color: #1976d2;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state img {
            width: 120px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: #555;
            margin-bottom: 10px;
            font-size: 20px;
        }

        .empty-state p {
            color: #777;
            font-size: 14px;
        }

        /* Messages */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid transparent;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            border-radius: 8px;
            width: 400px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .close {
            font-size: 24px;
            cursor: pointer;
            color: #777;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-group select,
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 15px;
        }

        .form-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            border: none;
            font-weight: 500;
        }

        .btn-primary {
            background-color: #4CAF50;
            color: white;
        }

        .btn-secondary {
            background-color: #ddd;
            color: #333;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 200px;
                padding: 15px;
            }

            .stats-container {
                grid-template-columns: repeat(2, 1fr);
            }

            .filters {
                flex-direction: column;
                gap: 15px;
                align-items: stretch;
            }

            .filter-tabs {
                flex-wrap: wrap;
            }

            .search-box input {
                width: 100%;
            }

            .products-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 1000;
            }

            .main-content {
                margin-left: 0;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                 <img src="{{ asset('dist/logo.png') }}" alt="Recyco">
                <h2>Recyco Admin</h2>
            </div>

 <div class="sidebar-menu">
                <a href="{{ route('admin.index') }}" class="menu-item active" style="color: white; text-decoration: none;">
                    <i class="fas fa-shopping-bag"></i>
                    <span>Kelola Pesanan</span>
                </a>
                <a href="{{ route('admin.product.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-box"></i>
                    <span>Produk</span>
                </a>
                <a href="{{ route('admin.customer.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-users"></i>
                    <span>Pelanggan</span>
                </a>
                <a href="{{ route('admin.report.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>
                <a href="{{ route('admin.settings.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-cog"></i>
                    <span>Pengaturan</span>
                </a>
            </div>
            <div class="admin-info">
                <div class="admin-name">Administrator</div>
                <div class="admin-role">Administrator</div>
                <a href="admin_dashboard.php?action=logout" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="page-header">
                <h1>Produk</h1>
                <div class="date">Wednesday, 07 May 2025</div>
            </div>

            <!-- Alert Messages -->
            <div class="alert alert-success" style="display: none;" id="successAlert">
                <span id="successMessage"></span>
            </div>

            <div class="alert alert-danger" style="display: none;" id="errorAlert">
                <span id="errorMessage"></span>
            </div>

            <!-- Stats Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Total Produk</h3>
                    <div class="count">{{ number_format($productTotal, 0, ',', '.') }}</div>
                </div>
                <div class="stat-card">
                    <h3>Produk Yang Diajukan</h3>
                    <div class="count">{{ number_format($productPendingTotal, 0, ',', '.') }}</div>
                </div>
                <div class="stat-card">
                    <h3>Disetujui</h3>
                    <div class="count">{{ number_format($productApproveTotal, 0, ',', '.') }}</div>
                </div>
                <div class="stat-card">
                    <h3>Ditolak</h3>
                    <div class="count">{{ number_format($productRejectTotal, 0, ',', '.') }}</div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters">
                <div class="filter-tabs">
                    <a href="{{ route('admin.product.index') }}" class="filter-tab active" data-filter="all">Semua</a>
                    <a href="{{ route('admin.product.index', ['status' => 0]) }}" class="filter-tab"
                        data-filter="pending">Produk Yang Diajukan</a>
                    <a href="{{ route('admin.product.index', ['status' => 1]) }}" class="filter-tab"
                        data-filter="approved">Disetujui</a>
                    <a href="{{ route('admin.product.index', ['status' => -1]) }}" class="filter-tab"
                        data-filter="rejected">Ditolak</a>
                </div>

                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Cari produk...">
                    <button type="button" id="searchBtn"><i class="fas fa-search"></i> Cari</button>
                </div>
            </div>

            <!-- Products Container -->
            <div class="products-container">
                @if (count($data) > 0)
                    <div class="products-grid" id="productsGrid">
                        @foreach ($data as $item)
                            <!-- Sample Product Cards -->
                            <div class="product-card" data-status="pending">
                                <div class="product-image">
                                    <img src="{{ $item->image }}" alt="Produk 1"
                                        style="width: 100%; height: 100%; object-fit: cover;"
                                        onerror="this.style.display='none'; this.parentNode.innerHTML='<span>Tidak ada gambar produk</span>'">
                                </div>
                                <div class="product-info">
                                    <div class="product-name">{{ $item->name }}</div>
                                    <div class="product-price">Rp {{ number_format($item->price, 0, ',', '.') }}</div>
                                    @switch($item->status)
                                        @case(0)
                                            <span class="product-status status-pending">Menunggu Persetujuan</span>
                                        @break

                                        @case(1)
                                            <span class="product-status status-pending">Disetujui</span>
                                        @break

                                        @case(-1)
                                            <span class="product-status status-pending">Ditolak</span>
                                        @break
                                    @endswitch

                                    @if ($item->status == '0')
                                        <div class="product-actions">
                                            <a class="action-btn btn-approve"
                                                href="{{ route('admin.product.update_status', ['product' => $item->id, 'status' => '1']) }}">
                                                <i class="fas fa-check"></i> Setujui
                                            </a>
                                            <a class="action-btn btn-reject"
                                                href="{{ route('admin.product.update_status', ['product' => $item->id, 'status' => '-1']) }}">
                                                <i class="fas fa-times"></i> Tolak
                                            </a>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <!-- Empty State (hidden by default) -->
                    <div class="empty-state" id="emptyState">
                        <img src="image/empty-box.png" alt="No Products" onerror="this.style.display='none'">
                        <h3>Tidak ada produk ditemukan</h3>
                        <p>Belum ada produk yang sesuai dengan filter atau pencarian Anda.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Status Update Modal -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Update Status Produk</h2>
                <span class="close">&times;</span>
            </div>

            <form id="statusForm">
                <input type="hidden" id="productId" value="">

                <div class="form-group">
                    <label for="productStatus">Status Produk:</label>
                    <select id="productStatus" required>
                        <option value="pending">Menunggu Persetujuan</option>
                        <option value="approved">Disetujui</option>
                        <option value="rejected">Ditolak</option>
                    </select>
                </div>

                <div class="form-buttons">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Filter functionality
        const filterTabs = document.querySelectorAll('.filter-tab');
        const productCards = document.querySelectorAll('.product-card');
        const productsGrid = document.getElementById('productsGrid');
        const emptyState = document.getElementById('emptyState');
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.getElementById('searchBtn');

        // Filter products
        filterTabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();

                // Update active tab
                filterTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');

                const filter = this.getAttribute('data-filter');
                filterProducts(filter);
            });
        });

        function filterProducts(filter) {
            let visibleCount = 0;

            productCards.forEach(card => {
                const status = card.getAttribute('data-status');

                if (filter === 'all' || status === filter) {
                    card.style.display = 'block';
                    visibleCount++;
                } else {
                    card.style.display = 'none';
                }
            });

            // Show/hide empty state
            if (visibleCount === 0) {
                productsGrid.style.display = 'none';
                emptyState.style.display = 'block';
            } else {
                productsGrid.style.display = 'grid';
                emptyState.style.display = 'none';
            }
        }

        // Search functionality
        function searchProducts() {
            const searchTerm = searchInput.value.toLowerCase();
            let visibleCount = 0;

            productCards.forEach(card => {
                const productName = card.querySelector('.product-name').textContent.toLowerCase();
                const productPrice = card.querySelector('.product-price').textContent.toLowerCase();

                if (productName.includes(searchTerm) || productPrice.includes(searchTerm)) {
                    if (card.style.display !== 'none') {
                        visibleCount++;
                    }
                } else {
                    card.style.display = 'none';
                }
            });

            // Show/hide empty state
            if (visibleCount === 0) {
                productsGrid.style.display = 'none';
                emptyState.style.display = 'block';
            } else {
                productsGrid.style.display = 'grid';
                emptyState.style.display = 'none';
            }
        }

        searchBtn.addEventListener('click', searchProducts);
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });

        // Product status update
        function updateProductStatus(productId, status) {
            // Simulate API call
            setTimeout(() => {
                const card = document.querySelector(`[data-status]`);
                if (card) {
                    card.setAttribute('data-status', status);
                    const statusBadge = card.querySelector('.product-status');
                    const actionsDiv = card.querySelector('.product-actions');

                    // Update status badge
                    statusBadge.className = `product-status status-${status}`;
                    if (status === 'approved') {
                        statusBadge.textContent = 'Disetujui';
                    } else if (status === 'rejected') {
                        statusBadge.textContent = 'Ditolak';
                    } else {
                        statusBadge.textContent = 'Menunggu Persetujuan';
                    }

                    // Update action buttons
                    if (status === 'approved' || status === 'rejected') {
                        actionsDiv.innerHTML = `
                            <button class="action-btn btn-edit" onclick="editProduct(${productId})">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                        `;
                    }

                    showAlert('success',
                        `Status produk berhasil diperbarui menjadi ${status === 'approved' ? 'Disetujui' : 'Ditolak'}`
                    );
                }
            }, 500);
        }

        function editProduct(productId) {
            console.log('Edit product:', productId);
            showAlert('success', 'Fitur edit produk akan segera tersedia');
        }

        // Modal functionality
        const modal = document.getElementById('statusModal');
        const span = document.getElementsByClassName('close')[0];

        function openStatusModal(productId, currentStatus) {
            document.getElementById('productId').value = productId;
            document.getElementById('productStatus').value = currentStatus;
            modal.style.display = 'flex';
        }

        function closeModal() {
            modal.style.display = 'none';
        }

        span.onclick = closeModal;

        window.onclick = function(event) {
            if (event.target == modal) {
                closeModal();
            }
        }

        // Form submission
        document.getElementById('statusForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const productId = document.getElementById('productId').value;
            const status = document.getElementById('productStatus').value;

            updateProductStatus(productId, status);
            closeModal();
        });
