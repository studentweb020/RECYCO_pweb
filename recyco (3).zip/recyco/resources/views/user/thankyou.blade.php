<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terima Kasih | Recyco</title>
    <link rel="stylesheet" href="{{ asset('dist/menu.css') }}">
    <style>
        .thank-you-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .thank-you-icon {
            font-size: 80px;
            color: #2e8b57;
            margin-bottom: 20px;
        }

        .order-summary {
            margin: 30px 0;
            text-align: left;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }

        .order-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 10px 0;
            border-bottom: 1px solid #f5f5f5;
        }

        .btn-back {
            display: inline-block;
            background-color: #2e8b57;
            color: white;
            padding: 12px 30px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            transition: background-color 0.3s;
        }

        .btn-back:hover {
            background-color: #3cb371;
        }

        .order-details {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <img src="{{ asset('dist/logo.png') }}" alt="Recyco" class="logo-image">
            <span>Recyco</span>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Cari produk eco-friendly...">
        </div>
        <div class="nav-icons">
            <div class="icon">🔔</div>
            <a href="{{ route('cart.index') }}">
                🛒
            </a>
            <div class="icon">👤</div>
        </div>
    </header>

    <div class="thank-you-container">
        <div class="thank-you-icon">✓</div>
        <h1>Terima Kasih atas Pesanan Anda!</h1>
        <p>Pesanan Anda telah berhasil diproses. Kami akan mengirimkan detail pembayaran ke email Anda.</p>

        <div class="order-details">
            <h3>Detail Pesanan</h3>
            <div class="order-summary">
                @php

                @endphp
                @foreach ($order['item_order'] as $item)
                    @php
                        $product = json_decode($item->product_attributes);
                    @endphp

                    <div class="order-row">
                        <span>Produk:</span>
                        <span>{{ $product->name }}</span>
                    </div>
                    <div class="order-row">
                        <span>Jumlah:</span>
                        <span>{{ $item->qty }}</span>
                    </div>
                    <div class="order-row">
                        <span>Harga Satuan:</span>
                        <span>Rp{{ number_format($product->price, 0, ',', '.') }}</span>
                    </div>
                    <hr>
                @endforeach
                <div class="order-row">
                    <span>Subtotal:</span>
                    <span>Rp{{ number_format($order['order']->total, 0, ',', '.') }}</span>
                </div>
                <div class="order-row">
                    <span>Ongkos Kirim:</span>
                    <span>Rp15.000</span>
                </div>
                <div class="order-row" style="font-weight: bold;">
                    <span>Total Pembayaran:</span>
                    <span>Rp{{ number_format($order['order']->total + 15000, 0, ',', '.') }}</span>
                </div>
                <div class="order-row">
                    <span>Metode Pembayaran:</span>
                    <span>{{ $order['order']->payment_method }}</span>
                </div>
                <div class="order-row">
                    <span>Alamat Pengiriman:</span>
                    <span>{{ $order['order']->address }}</span>
                </div>
                <div class="order-row">
                    <span>Tanggal Pesanan:</span>
                    <span>{{ $order['timestamp'] }}</span>
                </div>
            </div>
        </div>

        <a href="{{ route('market.index') }}" class="btn-back">Kembali ke Beranda</a>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Recyco - Marketplace Produk Eco-friendly</p>
        </div>
    </footer>

    <script>
        localStorage.removeItem('cart');
        // Confetti effect
        setTimeout(() => {
            const confettiSettings = {
                target: 'thank-you-icon',
                max: 150,
                size: 1.5,
                animate: true,
                props: ['circle', 'square', 'triangle', 'line'],
                colors: [
                    [217, 80, 138],
                    [254, 126, 125],
                    [255, 180, 131],
                    [142, 198, 65],
                    [61, 165, 217]
                ],
                clock: 25,
                rotate: true,
                start_from_edge: true,
                respawn: true
            };

            const confetti = new ConfettiGenerator(confettiSettings);
            confetti.render();

            setTimeout(() => {
                confetti.clear();
            }, 3000);
        }, 500);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.4.0/dist/confetti.browser.min.js"></script>
</body>

</html>
