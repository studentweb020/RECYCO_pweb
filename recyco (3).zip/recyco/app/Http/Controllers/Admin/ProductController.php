<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $productTotal = Product::count();
        $productPendingTotal = Product::where('status', '0')->count();
        $productApproveTotal = Product::where('status', '1')->count();
        $productRejectTotal = Product::where('status', '-1')->count();

        $product = Product::query();

        if ($request->has('status')) {
            $product = $product->where('status', $request->status);
        }

        $product = $product->get();


        return view('admin.product', [
            'productTotal' => $productTotal,
            'productPendingTotal' => $productPendingTotal,
            'productApproveTotal' => $productApproveTotal,
            'productRejectTotal' => $productRejectTotal,
            'data' => $product,
        ]);
    }

    public function update_status(Product $product, $status)
    {
        $product->update(['status' => $status]);

        return redirect()->back();
    }
}
