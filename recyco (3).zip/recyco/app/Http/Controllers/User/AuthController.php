<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function login()
    {
        return view('user.login');
    }

    public function do_login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::attempt($credentials)) {
            return redirect()->route('index');
        }

        return back()->withErrors([
            'error' => 'Email atau password salah.',
        ]);
    }

    public function register()
    {
        return view('user.register');
    }

    public function do_register(Request $request)
    {
        $request->validate([
            'username' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8',
            'mother_name' => 'required|string|max:255',
        ]);

        $user = User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'security_question' => 'Apa nama ibu kandung Anda?',
            'security_answer' => strtolower(trim($request->mother_name)),
        ]);

        Auth::login($user);

        return redirect()->route('index');
    }

    public function forgot_password()
    {
        return view('user.forgot_password');
    }

    public function do_forgot_password(Request $request)
    {
        // Step 1: Verify email and show security question
        if (!$request->has('security_answer')) {
            $request->validate([
                'email' => 'required|email',
            ]);

            $user = User::where('email', $request->email)->first();

            if (!$user) {
                return back()->withErrors([
                    'email' => 'Email tidak ditemukan dalam sistem kami.',
                ])->withInput();
            }

            // Store email in session for next step
            session(['reset_email' => $request->email]);

            return view('user.forgot_password', [
                'show_question' => true,
                'security_question' => $user->security_question,
                'email' => $request->email,
            ]);
        }

        // Step 2: Verify security answer
        $request->validate([
            'security_answer' => 'required|string',
        ]);

        $email = session('reset_email');
        if (!$email) {
            return redirect()->route('forgot_password')->withErrors([
                'error' => 'Sesi telah berakhir. Silakan mulai ulang proses reset password.',
            ]);
        }

        $user = User::where('email', $email)->first();

        if (!$user) {
            return redirect()->route('forgot_password')->withErrors([
                'error' => 'Terjadi kesalahan. Silakan coba lagi.',
            ]);
        }

        // Verify security answer (case-insensitive)
        if (strtolower(trim($request->security_answer)) !== $user->security_answer) {
            return back()->withErrors([
                'security_answer' => 'Jawaban keamanan tidak sesuai.',
            ])->with([
                'show_question' => true,
                'security_question' => $user->security_question,
                'email' => $email,
            ]);
        }

        // Generate reset token
        $reset_token = Str::random(60);
        $user->update([
            'reset_token' => $reset_token,
            'reset_token_expires' => now()->addMinutes(30), // Token valid for 30 minutes
        ]);

        // Clear session
        session()->forget('reset_email');

        // Redirect to reset password with token
        return redirect()->route('reset_password', ['token' => $reset_token]);
    }

    public function reset_password($token)
    {
        $user = User::where('reset_token', $token)
            ->where('reset_token_expires', '>', now())
            ->first();

        if (!$user) {
            return redirect()->route('forgot_password')->withErrors([
                'error' => 'Token tidak valid atau telah kedaluwarsa.',
            ]);
        }

        return view('user.change_password', [
            'token' => $token,
            'email' => $user->email,
        ]);
    }

    public function do_reset_password(Request $request, $token)
    {
        $request->validate([
            'password' => 'required|min:8|confirmed',
        ]);

        $user = User::where('reset_token', $token)
            ->where('reset_token_expires', '>', now())
            ->first();

        if (!$user) {
            return redirect()->route('forgot_password')->withErrors([
                'error' => 'Token tidak valid atau telah kedaluwarsa.',
            ]);
        }

        // Update password and clear reset token
        $user->update([
            'password' => Hash::make($request->password),
            'reset_token' => null,
            'reset_token_expires' => null,
        ]);

        // Redirect to login
        return redirect()->route('login')
            ->with('success', 'Password berhasil diubah. Silakan masuk dengan password baru Anda.');
    }

    public function change_password()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->withErrors([
                'error' => 'Silakan login terlebih dahulu.',
            ]);
        }

        return view('user.change_password');
    }

    public function do_change_password(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('login')->withErrors([
                'error' => 'Silakan login terlebih dahulu.',
            ]);
        }

        $request->validate([
            'current_password' => 'required',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = Auth::user();

        // Verify current password
        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors([
                'error' => 'Password saat ini tidak sesuai.',
            ]);
        }

        // Update password
        $user->update([
            'password' => Hash::make($request->password),
        ]);

        // Log out and redirect to login
        Auth::logout();

        return redirect()->route('login')
            ->with('success', 'Password berhasil diubah. Silakan login kembali.');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }
}