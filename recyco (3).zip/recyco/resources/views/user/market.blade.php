<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco - Marketplace Produk Eco-Friendly</title>
    <link rel="stylesheet" href="{{ asset('dist/menu.css') }}">
    <style>
        /* Additional inline styles to ensure no underlines anywhere */
        a,
        a:hover,
        a:visited,
        a:active,
        a:focus {
            text-decoration: none !important;
            color: inherit;
        }

        .nav-item a {
            text-decoration: none !important;
            color: inherit;
        }

        .btn-checkout {
            background-color: #2e8b57;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        .btn-checkout:hover {
            background-color: #3cb371;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <a href="/">
                <img src="{{ asset('dist/logo.png') }}" alt="Recyco" class="logo-image">
                <span>Recyco</span>
            </a>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Cari produk eco-friendly...">
        </div>
        <div class="nav-icons">
            <div class="icon">
    <a href="{{ route('notification') }}">
        🔔
    </a>
</div>



            <div class="icon">
                <a href="{{ route('cart.index') }}">
                    🛒
                </a>
            </div>
            <div class="icon">
                <a href="">
                    👤
                </a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="banner-section">
            <div class="promo-banner">
                <h3>Promo Spesial untuk Produk Pilihan!</h3>
                <p>Dapatkan menarik untuk produk eco-friendly favoritmu.</p>
                <p>➡️ Cek sekarang sebelum kehabisan!</p>
            </div>
            <div class="service-banner">
                <h3>Produk & Layanan Terbaik dari RECYCO!</h3>
                <p>Temukan solusi ramah lingkungan yang terpercaya hanya di recyco.</p>
                <p>🌿 Ikut andil selamatkan bumi!</p>
            </div>
        </div>


        <div class="nav-menu">
            <?php foreach ($navItems as $item): ?>
            <div class="nav-item">
                <a href="{{ $item['link'] }}">
                    <div class="nav-icon">{{ $item['icon'] }}</div>
                    <div>{{ $item['name'] }}</div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>


        <h3 class="section-title">Rekomendasi produk</h3>

        <div class="product-grid">
            <?php if (count($products) > 0): ?>
            <?php foreach ($products as $product): ?>
            <div class="product-card">
                <div class="product-image">
                    <img src="{{ $product->image }}" alt="{{ $product->name }}">
                </div>
                <div class="product-info">
                    <h4>{{ $product->name }}</h4>
                    <p class="price">Rp{{ number_format($product->price, 0, ',', '.') }}</p>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <a href="{{ route('checkout.index', $product->id) }}" class="btn-checkout"
                            style="display: block; flex: 1; color: white; text-align: center;">Beli</a>
                        <button class="btn-checkout btn-add-cart" data-product="{{ json_encode($product) }}"
                            style="background-color: #312e8b;">Add Cart</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <p class="no-products">Tidak ada produk yang tersedia saat ini.</p>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Recyco - Marketplace Produk Eco-friendly</p>
        </div>
    </footer>
</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {
        function saveCart(data) {
            localStorage.setItem('cart', JSON.stringify(data));
        }

        $(document).on('click', '.btn-add-cart', function(e) {
            e.preventDefault();
            const product = $(this).data('product');
            product.qty = 1;
            var cart = JSON.parse(localStorage.getItem('cart') || '[]');

            const existing = cart.find(item => item.id === product.id);
            if (existing) {
                existing.qty += 1;
            } else {
                cart.push(product);
            }

            saveCart(cart);

            alert('Tambah keranjang sukses');
        });
    });
</script>

</html>
