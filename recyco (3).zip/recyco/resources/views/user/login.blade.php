<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco - Sign In</title>
    <link rel="stylesheet" href="{{ asset('dist/style.css') }}">
</head>

<body>
    <div class="container">
        <div class="login-card">
            <h1 class="title">Sign In to Recyco</h1>
            <p class="subtitle">Welcome back! Please sign in to continue.</p>

            @if ($errors->any())
                <div class="error-message">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('do_login') }}">
                @csrf
                <div class="form-group">
                    <label for="email">User Name / Email Address</label>
                    <input type="text" id="email" name="email"
                        placeholder="Please enter your user name / email" required>
                </div>

                <div class="form-group password-group">
                    <label for="password">Password</label>
                    <a href="{{ route('forgot_password') }}" class="forgot-link">Forgot?</a>
                    <input type="password" id="password" name="password" placeholder="Please enter your password"
                        required>
                </div>

                <button type="submit" class="signin-btn">Sign In</button>
            </form>

            <p class="signup-prompt">Don't have an account? <a href="{{ route('register') }}" class="signup-link">Sign
                    Up</a>
            </p>
        </div>
    </div>
</body>

</html>
