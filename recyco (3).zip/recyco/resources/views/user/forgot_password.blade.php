<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Recyco</title>
    <link rel="stylesheet" href="{{ asset('dist/style.css') }}">
    <script>
        // Validasi client-side untuk memastikan field tidak kosong
        function validateForm() {
            const answer = document.querySelector('[name="security_answer"]')?.value.trim();
            if (answer === "") {
                alert("Silakan masukkan jawaban keamanan Anda");
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
    <div class="container">
        <div class="login-card">
            <h1 class="title">Reset Password</h1>

            @if ($errors->any())
                <div class="error-message">
                    @foreach ($errors->all() as $error)
                        {{ $error }}
                    @endforeach
                </div>
            @endif

            @if (session('success'))
                <div class="success-message">
                    {{ session('success') }}
                </div>
            @endif

            @if (!isset($show_question) || !$show_question)
                <!-- Form Langkah 1: Input Email -->
                <p class="subtitle">Masukkan email Anda untuk memverifikasi identitas</p>
                <form method="POST" action="{{ route('do_forgot_password') }}">
                    @csrf
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required 
                               value="{{ old('email') }}"
                               placeholder="Enter your registered email">
                    </div>
                    <button type="submit" class="signin-btn">Lanjutkan</button>
                </form>
            @else
                <!-- Form Langkah 2: Pertanyaan Keamanan -->
                <p class="subtitle">Silakan jawab pertanyaan keamanan Anda</p>
                <form method="POST" action="{{ route('do_forgot_password') }}" onsubmit="return validateForm()">
                    @csrf
                    <div class="form-group">
                        <label>{{ $security_question }}</label>
                        <input type="text" name="security_answer" required 
                               placeholder="Masukkan jawaban Anda"
                               autocomplete="off">
                        <small class="form-text">Perhatikan huruf besar/kecil dan spasi</small>
                    </div>
                    <button type="submit" class="signin-btn">Verifikasi</button>
                </form>
                
                <!-- Back to email form -->
                <div style="margin-top: 15px;">
                    <a href="{{ route('forgot_password') }}" class="signin-link">← Kembali ke form email</a>
                </div>
            @endif

            <p class="signin-prompt">Ingat password Anda? <a href="{{ route('login') }}" class="signin-link">Sign In</a></p>
        </div>
    </div>
</body>

</html>