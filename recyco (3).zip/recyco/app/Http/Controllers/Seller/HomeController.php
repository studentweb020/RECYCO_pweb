<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    public function index()
    {
        $data = Product::where('seller_id', Auth::guard('seller')->user()->id)->get();

        return view('seller.home', [
            'data' => $data,
        ]);
    }

    public function add_product()
    {
        return view('seller.add_product');
    }

    public function store_product(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'stock' => 'required|integer|min:0',
            'price' => 'required|numeric|min:0',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = Str::uuid() . '.' . $extension;

            // Simpan file ke storage/app/public/products
            $path = $file->storeAs('products', $filename, 'public');
            $validated['image'] = $path;
        }

        $validated['seller_id'] = Auth::guard('seller')->user()->id;

        Product::create($validated);

        return redirect()->route('seller.index')->with('success', 'Produk berhasil ditambahkan!');
    }

    public function logout()
    {
        Auth::guard('seller')->logout();
        Session::flush();
        Session::regenerate();
        return redirect()->route('seller.login')->with('success', 'Anda berhasil logout');
    }
}