<?php

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\HomeController as AdminHomeController;
use App\Http\Controllers\Admin\CustomerController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Seller\AuthController as SellerAuthController;
use App\Http\Controllers\Seller\HomeController as SellerHomeController;
use App\Http\Controllers\User\AuthController;
use App\Http\Controllers\User\CartController;
use App\Http\Controllers\User\CheckoutController;
use App\Http\Controllers\User\HomeController;
use App\Http\Controllers\User\MarketController;
use App\Http\Controllers\User\OrderController;
use App\Http\Controllers\User\NotificationController;
use App\Http\Controllers\User\KomunitasController;
use App\Http\Controllers\User\TipsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::controller(HomeController::class)->group(function () {
    Route::get('/', 'index')->name('index');
});

Route::middleware(['isguest:user'])->group(function () {
    Route::controller(AuthController::class)->group(function () {
        Route::get('login', 'login')->name('login');
        Route::post('login', 'do_login')->name('do_login');
        Route::get('register', 'register')->name('register');
        Route::post('register', 'do_register')->name('do_register');
        
        // Forgot Password Routes
        Route::get('forgot-password', 'forgot_password')->name('forgot_password');
        Route::post('forgot-password', 'do_forgot_password')->name('do_forgot_password');
        Route::get('reset-password/{token}', 'reset_password')->name('reset_password');
        Route::post('reset-password/{token}', 'do_reset_password')->name('do_reset_password');
    });
});

Route::middleware(['islogged:user'])->group(function () {
    Route::prefix('market')->name('market.')->controller(MarketController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::get('products', 'products')->name('products');
        Route::get('product/{product}', 'show')->name('product.show');
        Route::get('switch-to-seller', 'switchToSeller')->name('switch_to_seller');
    });

    Route::prefix('checkout')->name('checkout.')->controller(CheckoutController::class)->group(function () {
        Route::get('thankyou', 'thankyou')->name('thankyou');
        Route::get('/{product}', 'index')->name('index');
        Route::post('/{product}', 'do_checkout')->name('do_checkout');
    });

    Route::prefix('order')->name('order.')->controller(OrderController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::post('update/{order}', 'update')->name('update');
        Route::get('delete/{order}', 'delete')->name('delete');
        Route::get('cancel/{order}', 'cancel')->name('cancel');
    });

    Route::prefix('cart')->name('cart.')->controller(CartController::class)->group(function () {
        Route::get('/', 'index')->name('index');
        Route::post('/', 'store')->name('store');
    });

    Route::prefix('komunitas')->name('komunitas.')->controller(KomunitasController::class)->group(function () {
        Route::get('/', 'index')->name('index');
    });

    Route::prefix('tips')->name('tips.')->controller(TipsController::class)->group(function () {
        Route::get('/', 'index')->name('index');
    });

    Route::get('notification', [NotificationController::class, 'index'])->name('notification');

    Route::controller(AuthController::class)->group(function () {
        Route::get('change-password', 'change_password')->name('change_password');
        Route::post('change-password', 'do_change_password')->name('do_change_password');
        Route::get('logout', 'logout')->name('logout');
    });
});

// Seller
Route::prefix('seller')->name('seller.')->group(function () {
    Route::middleware(['isguest:seller'])->controller(SellerAuthController::class)->group(function () {
        Route::get('login', 'login')->name('login');
        Route::post('login', 'do_login')->name('do_login');
        Route::get('register', 'register')->name('register');
        Route::post('register', 'do_register')->name('do_register');
    });

    Route::middleware('islogged:seller')->group(function () {
        Route::controller(SellerHomeController::class)->group(function () {
            Route::get('/', 'index')->name('index');
            Route::get('/product/add', 'add_product')->name('add_product');
            Route::post('/product/add', 'store_product')->name('store_product');
            Route::get('logout', 'logout')->name('logout');
        });
    });
});

// Admin
Route::prefix('admin')->name('admin.')->group(function () {
    Route::middleware(['isguest:admin'])->controller(AdminAuthController::class)->group(function () {
        Route::get('login', 'login')->name('login');
        Route::post('login', 'do_login')->name('do_login');
    });

    Route::middleware('islogged:admin')->group(function () {
        Route::controller(AdminHomeController::class)->group(function () {
            Route::get('/', 'index')->name('index');
            Route::post('update-status', 'update_status')->name('update_status');
        });

        Route::prefix('product')->name('product.')->controller(ProductController::class)->group(function () {
            Route::get('/', 'index')->name('index');
            Route::get('update-status/{product}/{status}', 'update_status')->name('update_status');
        });

        Route::prefix('customer')->name('customer.')->controller(CustomerController::class)->group(function () {
            Route::get('/', 'index')->name('index');
        });

        Route::prefix('settings')->name('settings.')->controller(SettingsController::class)->group(function () {
            Route::get('/', 'index')->name('index');
            Route::patch('/', 'update')->name('update');
        });

        Route::prefix('report')->name('report.')->controller(ReportController::class)->group(function () {
            Route::get('/', 'index')->name('index');
        });

        Route::controller(AdminAuthController::class)->group(function () {
            Route::get('logout', 'logout')->name('logout');
        });
    });
});