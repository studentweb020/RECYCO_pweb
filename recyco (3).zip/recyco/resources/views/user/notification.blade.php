<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi - Recyco</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'recyco-green': '#7dd3a0',
                        'recyco-green-dark': '#5bc97d',
                    }
                }
            }
        }
    </script>
</head>
<body class="font-sans bg-gray-50 text-gray-800">
    <div class="max-w-4xl mx-auto bg-white min-h-screen shadow-xl">
        <!-- Header -->
        <header class="flex justify-between items-center px-6 py-4 bg-white border-b border-gray-200">
            <div class="flex items-center gap-3">
                <img src="{{ asset('dist/logo.png') }}" alt="Recyco" class="w-8 h-8">
                <span class="text-xl font-bold text-gray-800">Recyco</span>
            </div>
            <div class="flex gap-4">
                <button class="p-2 rounded-full hover:bg-gray-100 transition-colors">
                    <span class="text-lg">🔔</span>
                </button>
                <button class="p-2 rounded-full hover:bg-gray-100 transition-colors">
                    <span class="text-lg">🛒</span>
                </button>
                <button class="p-2 rounded-full hover:bg-gray-100 transition-colors">
                    <span class="text-lg">👤</span>
                </button>
            </div>
        </header>

        <!-- Title Section -->
        <div class="bg-gradient-to-br from-recyco-green to-recyco-green-dark py-8 px-6 text-center">
            <h1 class="text-white text-3xl font-bold drop-shadow-sm">Notifikasi</h1>
        </div>

        <!-- Notifications List -->
        <div class="p-6">
            <div class="flex flex-col gap-5 mb-8">
                <!-- Notification 1 -->
                <div class="flex gap-4 p-5 bg-white rounded-xl shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-200 border-l-4 border-green-400">
                    <div class="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center text-xl flex-shrink-0">
                        <span>🛍️</span>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-base font-semibold text-gray-800 mb-2 leading-snug">Jangan lupa! Produk daur ulangmu masih di keranjang.</h3>
                        <p class="text-sm text-gray-600 mb-2 leading-relaxed">Dukung lingkungan dengan berbagai produk ramah lingkungan terbaru!</p>
                        <span class="text-xs text-gray-400 font-medium">1h lalu</span>
                    </div>
                </div>

                <!-- Notification 2 -->
                <div class="flex gap-4 p-5 bg-white rounded-xl shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-200 border-l-4 border-amber-400">
                    <div class="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center text-xl flex-shrink-0">
                        <span>🔔</span>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-base font-semibold text-gray-800 mb-2 leading-snug">Promo spesial hari ini: Diskon 20% untuk kerajinan dari plastik daur ulang!</h3>
                        <p class="text-sm text-gray-600 mb-2 leading-relaxed">Cek sekarang dan jangan sampai kehabisan!</p>
                        <span class="text-xs text-gray-400 font-medium">1h lalu</span>
                    </div>
                </div>

                <!-- Notification 3 -->
                <div class="flex gap-4 p-5 bg-white rounded-xl shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-200 border-l-4 border-blue-400">
                    <div class="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center text-xl flex-shrink-0">
                        <span>📦</span>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-base font-semibold text-gray-800 mb-2 leading-snug">Pesananmu sedang diproses! Terima kasih telah memilih produk ramah lingkungan.</h3>
                        <p class="text-sm text-gray-600 mb-2 leading-relaxed">Tunggu sebentar ya, produk daur ulang pilihanmu akan segera dikirim! 😊</p>
                        <span class="text-xs text-gray-400 font-medium">1h lalu</span>
                    </div>
                </div>
            </div>

            <!-- Read More Button -->
            <div class="text-center mt-8">
                <button class="bg-gradient-to-r from-recyco-green to-recyco-green-dark text-white px-8 py-3 rounded-full text-base font-semibold hover:-translate-y-1 hover:shadow-lg transition-all duration-300 shadow-md">
                    Read More
                </button>
            </div>
        </div>
    </div>
</body>
</html>