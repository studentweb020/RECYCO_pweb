<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;   
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index(Request $request)
    {
        $statusFilter = $request->status;
        $searchTerm = $request->search;

        $orders = Order::with('product')
            ->when($statusFilter, function ($q) use ($statusFilter) {
                $q->where('status', $statusFilter);
            })
            ->when($searchTerm, function ($q) use ($searchTerm) {
                $q->where(function ($query) use ($searchTerm) {
                    $query->where('id', 'like', "%$searchTerm%")
                        ->orWhere('name', 'like', "%$searchTerm%")
                        ->orWhere('email', 'like', "%$searchTerm%")
                        ->orWhereHas('product', fn($q) => $q->where('name', 'like', "%$searchTerm%"));
                });
            })
            ->latest()
            ->get();

        $statusCounts = Order::selectRaw('status, count(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status');

        return view('admin.dashboard', [
            'orders' => $orders,
            'statusCounts' => $statusCounts,
            'totalCount' => $statusCounts->sum(),
            'statusFilter' => $statusFilter,
            'searchTerm' => $searchTerm
        ]);
    }

    public function update_status(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,processing,shipped,delivered,cancelled'
        ]);

        try {
            $order = Order::where('id', $request->order_id)->first();
            $order->update($validated);

            return redirect()->route('admin.index')
                ->with('message', 'Status pesanan #' . $order->id . ' berhasil diperbarui menjadi ' . ucfirst($validated['status']));
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Gagal memperbarui status: ' . $e->getMessage());
        }
    }
}
