<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Saya | Recyco</title>
    <link rel="stylesheet" href="<?php echo e(asset('dist/menu.css')); ?>">
    <style>
        .orders-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }

        .order-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .order-product {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .order-product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
            margin-right: 15px;
        }

        .order-details {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 15px;
        }

        .detail-group {
            flex: 1;
            min-width: 200px;
        }

        .detail-label {
            font-weight: bold;
            color: #555;
            margin-bottom: 5px;
        }

        .status-pending {
            color: #ff9800;
        }

        .status-processing {
            color: #2196f3;
        }

        .status-shipped {
            color: #4caf50;
        }

        .status-delivered {
            color: #2e8b57;
        }

        .status-cancelled {
            color: #f44336;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn-edit {
            background-color: #2196f3;
            color: white;
        }

        .btn-delete {
            background-color: #f44336;
            color: white;
        }

        .btn-cancel {
            background-color: #ff9800;
            color: white;
        }

        .btn-update {
            background-color: #4caf50;
            color: white;
        }

        .btn:hover {
            opacity: 0.8;
        }

        .edit-form {
            margin-top: 15px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            display: none;
        }

        .form-row {
            margin-bottom: 10px;
        }

        .form-row label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-row input,
        .form-row select,
        .form-row textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .success {
            background-color: #dff0d8;
            color: #3c763d;
        }

        .error {
            background-color: #f2dede;
            color: #a94442;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <img src="<?php echo e(asset('dist/logo.png')); ?>" alt="Recyco" class="logo-image">
            <span>Recyco</span>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Cari produk eco-friendly...">
        </div>
        <div class="nav-icons">
            <div class="icon">🔔</div>
            <div class="icon">🛒</div>
            <div class="icon">👤</div>
        </div>
    </header>

    <div class="orders-container">
        <h1>Pesanan Saya</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if (empty($orders)): ?>
        <p>Anda belum memiliki pesanan.</p>
        <?php else: ?>
        <?php foreach ($orders as $order): ?>
        <div class="order-card">
            <div class="order-header">
                <h3>Order #<?php echo e($order->id); ?></h3>
                <span class="status-<?php echo e($order->status); ?>">
                    <?php
                    $status_map = [
                        'pending' => 'Menunggu Pembayaran',
                        'processing' => 'Sedang Diproses',
                        'shipped' => 'Dikirim',
                        'delivered' => 'Sampai',
                        'cancelled' => 'Dibatalkan',
                    ];
                    echo $status_map[$order->status];
                    ?>
                </span>
            </div>

            <?php
                $total = 0;
            ?>

            <?php $__currentLoopData = $order->item_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $product = json_decode($item->product_attributes);
                    $total += $product->price * $item->qty;
                ?>

                <div class="order-product">
                    <img src="<?php echo e($item->product->image); ?>" alt="<?php echo e($product->name); ?>" class="order-product-image">
                    <div>
                        <h4><?php echo e($product->name); ?></h4>
                        <p>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?> x <?php echo e($item->qty); ?></p>
                        <p>Total: Rp<?php echo e(number_format($product->price * $item->qty, 0, ',', '.')); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <br>

            <div class="order-details">
                <div class="detail-group">
                    <div class="detail-label">Nama Pemesan</div>
                    <div><?php echo e($order->name); ?></div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Email</div>
                    <div><?php echo e($order->email); ?></div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Alamat Pengiriman</div>
                    <div><?php echo e($order->address); ?></div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Total Pembayaran</div>
                    <div>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Metode Pembayaran</div>
                    <div><?php echo e($order->payment_method); ?></div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Tanggal Pesanan</div>
                    <div><?php echo e(date('d M Y H:i', strtotime($order->created_at))); ?></div>
                </div>
            </div>

            <?php if (!empty($order->notes)): ?>
            <div class="detail-group">
                <div class="detail-label">Catatan</div>
                <div><?php echo e($order->notes); ?></div>
            </div>
            <?php endif; ?>

            <div class="action-buttons">
                <?php if ($order->status== 'pending' || $order->status == 'processing'): ?>
                <button class="btn btn-edit" onclick="toggleEditForm('edit-form-<?php echo e($order->id); ?>')">Edit Alamat &
                    Pembayaran</button>

                <?php if ($order->status == 'pending'): ?>
                <a href="<?php echo e(route('order.delete', $order->id)); ?>" class="btn btn-delete"
                    onclick="return confirm('Apakah Anda yakin ingin menghapus pesanan ini?')">Hapus</a>
                <?php endif; ?>

                <?php if ($order->status != 'cancelled' && $order->status != 'delivered'): ?>
                <a href="<?php echo e(route('order.cancel', $order->id)); ?>" class="btn btn-cancel">Batalkan</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Edit form for address and payment method -->
            <?php if ($order->status == 'pending' || $order->status == 'processing'): ?>
            <div id="edit-form-<?php echo e($order->id); ?>" class="edit-form">
                <h4>Edit Detail Pesanan</h4>
                <form method="post" action="<?php echo e(route('order.update', $order->id)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-row">
                        <label for="address">Alamat Pengiriman:</label>
                        <textarea name="address" id="address" rows="3" required><?php echo e($order->address); ?></textarea>
                    </div>

                    <div class="form-row">
                        <label for="payment_method">Metode Pembayaran:</label>
                        <select name="payment_method" id="payment_method" required>
                            <option value="Transfer Bank"
                                <?php echo e($order->payment_method == 'Transfer Bank' ? 'selected' : ''); ?>>Transfer Bank
                            </option>
                            <option value="E-Wallet" <?php echo e($order->payment_method == 'E-Wallet' ? 'selected' : ''); ?>>
                                E-Wallet</option>
                            <option value="COD" <?php echo e($order->payment_method == 'COD' ? 'selected' : ''); ?>>COD (Cash On
                                Delivery)</option>
                            <option value="Kartu Kredit"
                                <?php echo e($order->payment_method == 'Kartu Kredit' ? 'selected' : ''); ?>>Kartu Kredit</option>
                        </select>
                    </div>

                    <div class="form-row">
                        <button type="submit" name="update_order" class="btn btn-update">Simpan Perubahan</button>
                        <button type="button" class="btn"
                            onclick="toggleEditForm('edit-form-<?php echo e($order->id); ?>')">Batal</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Recyco - Marketplace Produk Eco-friendly</p>
        </div>
    </footer>

    <script>
        // Toggle edit form visibility
        function toggleEditForm(formId) {
            const form = document.getElementById(formId);
            if (form.style.display === "block") {
                form.style.display = "none";
            } else {
                form.style.display = "block";
            }
        }

        // Confirm before deleting
        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('Apakah Anda yakin ingin menghapus pesanan ini?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\andre\recyco\resources\views/user/order.blade.php ENDPATH**/ ?>