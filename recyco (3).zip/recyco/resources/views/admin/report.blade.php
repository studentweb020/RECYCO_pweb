<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco Admin - Laporan</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid #3c546d;
        }

        .sidebar-header img {
            width: 40px;
            margin-right: 10px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
            color: white;
            text-decoration: none;
        }

        .menu-item.active {
            background-color: #3c546d;
            border-left: 4px solid #4CAF50;
        }

        .menu-item:hover {
            background-color: #3c546d;
            cursor: pointer;
        }

        .menu-item i {
            margin-right: 10px;
            font-size: 18px;
        }

        .admin-info {
            padding: 20px;
            border-top: 1px solid #3c546d;
            position: absolute;
            bottom: 20px;
            width: 100%;
        }

        .admin-name {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .logout-btn {
            color: #e74c3c;
            margin-top: 10px;
            display: inline-block;
            text-decoration: none;
        }

        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card h3 {
            font-size: 14px;
            color: #777;
            margin-bottom: 10px;
        }

        .stat-card .count {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }

        .stat-card.total {
            border-top: 3px solid #3498db;
        }

        .filters {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }

        .filter-tabs {
            display: flex;
            gap: 10px;
        }

        .filter-tab {
            padding: 8px 16px;
            border-radius: 20px;
            background-color: #eee;
            cursor: pointer;
            text-decoration: none;
            color: #555;
            font-size: 14px;
        }

        .filter-tab.active {
            background-color: #4CAF50;
            color: white;
        }

        .search-box {
            display: flex;
            gap: 10px;
        }

        .search-box input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 250px;
        }

        .search-box button {
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .orders-table {
            width: 100%;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #f5f5f5;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #555;
            border-bottom: 1px solid #ddd;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .empty-state {
            text-align: center;
            padding: 40px 0;
        }

        .empty-state img {
            width: 120px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: #555;
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #777;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
            text-align: center;
            display: inline-block;
        }

        .status-0 {
            background-color: #fff3e0;
            color: #ff9800;
        }

        .status-1 {
            background-color: #e8f5e9;
            color: #4caf50;
        }

        .status--1 {
            background-color: #ffebee;
            color: #f44336;
        }

        .action-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            margin-right: 5px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="{{ asset('dist/logo.png') }}" alt="Recyco">
                <h2>Recyco Admin</h2>
            </div>
            <div class="sidebar-menu">
                <a href="{{ route('admin.index') }}" class="menu-item {{ Route::is('admin.index') ? 'active' : '' }}">
                    <i class="fas fa-shopping-bag"></i>
                    <span>Kelola Pesanan</span>
                </a>
                <a href="{{ route('admin.product.index') }}" class="menu-item {{ Route::is('admin.product.*') ? 'active' : '' }}">
                    <i class="fas fa-box"></i>
                    <span>Produk</span>
                </a>
                <a href="{{ route('admin.customer.index') }}" class="menu-item {{ Route::is('admin.customer.*') ? 'active' : '' }}">
                    <i class="fas fa-users"></i>
                    <span>Pelanggan</span>
                </a>
                <a href="{{ route('admin.report.index') }}" class="menu-item {{ Route::is('admin.report.*') ? 'active' : '' }}">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>
                <a href="{{ route('admin.settings.index') }}" class="menu-item {{ Route::is('admin.settings.*') ? 'active' : '' }}">
                    <i class="fas fa-cog"></i>
                    <span>Pengaturan</span>
                </a>
            </div>
            <div class="admin-info">
                <div class="admin-name">{{ Auth::guard('admin')->user()->username }}</div>
                <div class="admin-role">Administrator</div>
                <a href="{{ route('admin.logout') }}" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="page-header">
                <h1>Laporan Keuangan</h1>
                <div class="date">{{ date('l, d F Y') }}</div>
            </div>

            @if (session('message'))
                <div class="alert alert-success">
                    {{ session('message') }}
                </div>
            @endif
            @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif

            <!-- Stats -->
            <div class="stats-container">
                <div class="stat-card total">
                    <h3>Total Pendapatan</h3>
                    <div class="count">Rp {{ number_format($totalRevenue, 0, ',', '.') }}</div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters">
                <div class="filter-tabs">
                    <a href="{{ route('admin.report.index') }}" class="filter-tab {{ empty(request('period')) ? 'active' : '' }}">Semua</a>
                    <a href="?period=weekly" class="filter-tab {{ request('period') === 'weekly' ? 'active' : '' }}">Mingguan</a>
                    <a href="?period=monthly" class="filter-tab {{ request('period') === 'monthly' ? 'active' : '' }}">Bulanan</a>
                </div>
                <form method="get" action="{{ route('admin.report.index') }}" class="search-box">
                    <input type="text" name="search" placeholder="Cari berdasarkan tanggal (YYYY-MM-DD)..." value="{{ htmlspecialchars(request('search') ?? '') }}">
                    @if (request('period'))
                        <input type="hidden" name="period" value="{{ htmlspecialchars(request('period')) }}">
                    @endif
                    <button type="submit"><i class="fas fa-search"></i> Cari</button>
                </form>
            </div>

            <!-- Report Table -->
            <div class="orders-table">
                @if (count($reports) > 0)
                    <table>
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Total Pesanan</th>
                                <th>Pendapatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($reports as $report)
                                <tr>
                                    <td>{{ date('d M Y', strtotime($report->date)) }}</td>
                                    <td>{{ $report->total_orders }}</td>
                                    <td>Rp {{ number_format($report->revenue, 0, ',', '.') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <div class="empty-state">
                        <img src="{{ asset('image/empty-box.png') }}" alt="No Reports">
                        <h3>Tidak ada laporan ditemukan</h3>
                        <p>Belum ada laporan yang sesuai dengan filter atau pencarian Anda.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</body>
</html>