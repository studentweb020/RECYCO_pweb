<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco Dashboard</title>
    <link rel="stylesheet" href="{{ asset('dist/seller.css') }}">
</head>

<body>
    <div class="dashboard-container">
        <!-- Header -->
        <header class="dashboard-header">
            <div class="dashboard-logo">
                <img src="{{ asset('dist/logo.png') }}" alt="Recyco" width="30px">
                <span class="dashboard-logo-text">Recyco</span>
            </div>
            <div class="dashboard-nav">
                <button class="dashboard-nav-btn">🔔</button>
                <button class="dashboard-nav-btn">👤</button>
            </div>
        </header>

        <!-- Main Content -->
        <main class="dashboard-main">
            <h1 class="dashboard-title">Produk Jualanmu</h1>

            <!-- Products Grid -->
            <div class="dashboard-products-grid">
                @foreach ($data as $item)
                    <div class="dashboard-product-card">
                        <div class="dashboard-product-image">
                            <img src="{{ $item->image }}" alt="{{ $item->name }}" class="dashboard-product-img">
                        </div>
                        <div class="dashboard-product-info">
                            <h3 class="dashboard-product-name">{{ $item->name }}</h3>
                            <p class="dashboard-product-price">Rp {{ number_format($item->price, 0, ',', '.') }}</p>
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Action Buttons -->
            <div class="dashboard-actions">
                <a href="{{ route('seller.add_product') }}" class="dashboard-btn dashboard-btn-primary">Add Products</a>
                <!-- Update Exit button to logout -->
                <a href="{{ route('seller.logout') }}" class="dashboard-btn dashboard-btn-danger" 
                   onclick="return confirm('Apakah Anda yakin ingin keluar?')">Exit</a>
            </div>
        </main>
    </div>
</body>

</html>