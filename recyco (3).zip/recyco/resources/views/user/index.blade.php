<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco - Sustainability with Style</title>
    <link rel="stylesheet" href="{{ asset('dist/style.css') }}">
</head>

<body>
    <div class="homepage">
        <header class="navbar">
            <div class="logo">
                <a href="/">
                    <img src="{{ asset('dist/logo.png') }}" alt="Recyco" class="logo-img">
                    <span class="logo-text">Recyco</span>
                </a>
            </div>
            <div class="nav-buttons">
                <span class="welcome-message">Welcome, {{ Auth::user()->username }}</span>
                <a href="{{ route('logout') }}" class="nav-btn">Logout</a>
            </div>
        </header>

        <div class="hero-section">
            <div class="hero-content">
                <h1 class="hero-title">
                    Shop Recycled <span class="recycling-icon">♻️</span> Goods . Learn to Reuse Smarter.<br>
                    Recyco — Sustainability with Style.
                </h1>
                <p class="hero-description">
                    Recyco isn't just a marketplace — it's a movement. Buy or sell high-quality recycled products
                    and get inspired with practical tips on how to reuse smartly and stylishly.
                </p>
                <div class="hero-buttons">
                    <a href="{{ route('menu') }}" class="hero-btn buy-sell-btn">
                        <span class="btn-icon">🛒</span> Buy & Sell Recycled Items
                    </a>
                    <a href="{{ route('menu') }}" class="hero-btn learn-btn">
                        <span class="btn-icon">📚</span> Learn DIY & Upcycling Ideas
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
