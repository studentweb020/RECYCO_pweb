<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Recyco</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        /* Layout */
        .container {
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid #3c546d;
        }

        .sidebar-header img {
            width: 40px;
            margin-right: 10px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
        }

        .menu-item.active {
            background-color: #3c546d;
            border-left: 4px solid #4CAF50;
        }

        .menu-item:hover {
            background-color: #3c546d;
            cursor: pointer;
        }

        .menu-item i {
            margin-right: 10px;
            font-size: 18px;
        }

        .admin-info {
            padding: 20px;
            border-top: 1px solid #3c546d;
            position: absolute;
            bottom: 20px;
            width: 100%;
        }

        .admin-name {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .logout-btn {
            color: #e74c3c;
            margin-top: 10px;
            display: inline-block;
            text-decoration: none;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card h3 {
            font-size: 14px;
            color: #777;
            margin-bottom: 10px;
        }

        .stat-card .count {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }

        .stat-card.total {
            border-top: 3px solid #3498db;
        }

        .stat-card.pending {
            border-top: 3px solid #f39c12;
        }

        .stat-card.processing {
            border-top: 3px solid #9b59b6;
        }

        .stat-card.shipped {
            border-top: 3px solid #2ecc71;
        }

        .stat-card.delivered {
            border-top: 3px solid #16a085;
        }

        .stat-card.cancelled {
            border-top: 3px solid #e74c3c;
        }

        /* Filters */
        .filters {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }

        .filter-tabs {
            display: flex;
            gap: 10px;
        }

        .filter-tab {
            padding: 8px 16px;
            border-radius: 20px;
            background-color: #eee;
            cursor: pointer;
            text-decoration: none;
            color: #555;
            font-size: 14px;
        }

        .filter-tab.active {
            background-color: #4CAF50;
            color: white;
        }

        .search-box {
            display: flex;
            gap: 10px;
        }

        .search-box input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 250px;
        }

        .search-box button {
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        /* Orders Table */
        .orders-table {
            width: 100%;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #f5f5f5;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #555;
            border-bottom: 1px solid #ddd;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .product-info {
            display: flex;
            align-items: center;
        }

        .product-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 10px;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
            text-align: center;
            display: inline-block;
        }

        .status-pending {
            background-color: #fff3e0;
            color: #ff9800;
        }

        .status-processing {
            background-color: #e3f2fd;
            color: #2196f3;
        }

        .status-shipped {
            background-color: #e8f5e9;
            color: #4caf50;
        }

        .status-delivered {
            background-color: #e0f2f1;
            color: #009688;
        }

        .status-cancelled {
            background-color: #ffebee;
            color: #f44336;
        }

        .action-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }

        /* Status Update Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow: auto;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            border-radius: 8px;
            width: 400px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .close {
            font-size: 24px;
            cursor: pointer;
            color: #777;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-group select,
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 15px;
        }

        .form-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background-color: #4CAF50;
            color: white;
        }

        .btn-secondary {
            background-color: #ddd;
            color: #333;
        }

        /* Messages */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 40px 0;
        }

        .empty-state img {
            width: 120px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: #555;
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #777;
        }
    </style>
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="<?php echo e(asset('dist/logo.png')); ?>" alt="Recyco">
                <h2>Recyco Admin</h2>
                </div>

            <div class="sidebar-menu">
                <a href="<?php echo e(route('admin.index')); ?>" class="menu-item active" style="color: white; text-decoration: none;">
                    <i class="fas fa-shopping-bag"></i>
                    <span>Kelola Pesanan</span>
                </a>
                <a href="<?php echo e(route('admin.product.index')); ?>" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-box"></i>
                    <span>Produk</span>
                </a>
                <a href="<?php echo e(route('admin.customer.index')); ?>" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-users"></i>
                    <span>Pelanggan</span>
                </a>
                <a href="<?php echo e(route('admin.report.index')); ?>" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>
                <a href="<?php echo e(route('admin.settings.index')); ?>" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-cog"></i>
                    <span>Pengaturan</span>
                </a>
            </div>

            <div class="admin-info">
                <div class="admin-name"><?php echo e(Auth::guard('admin')->user()->username); ?></div>
                <div class="admin-role">Administrator</div>
                <a href="<?php echo e(route('admin.logout')); ?>" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="page-header">
                <h1>Kelola Pesanan</h1>
                <div class="date"><?php echo e(date('l, d F Y')); ?></div>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success">
                <?php echo e($_SESSION['message']); ?>

            </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo e($_SESSION['error']); ?>

            </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-container">
                <div class="stat-card total">
                    <h3>Total Pesanan</h3>
                    <div class="count"><?php echo e($totalCount); ?></div>
                </div>
                <div class="stat-card pending">
                    <h3>Menunggu Pembayaran</h3>
                    <div class="count"><?php echo e(isset($statusCounts['pending']) ? $statusCounts['pending'] : 0); ?></div>
                </div>
                <div class="stat-card processing">
                    <h3>Sedang Diproses</h3>
                    <div class="count"><?php echo e(isset($statusCounts['processing']) ? $statusCounts['processing'] : 0); ?>

                    </div>
                </div>
                <div class="stat-card shipped">
                    <h3>Dikirim</h3>
                    <div class="count"><?php echo e(isset($statusCounts['shipped']) ? $statusCounts['shipped'] : 0); ?></div>
                </div>
                <div class="stat-card delivered">
                    <h3>Sampai</h3>
                    <div class="count"><?php echo e(isset($statusCounts['delivered']) ? $statusCounts['delivered'] : 0); ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters">
                <div class="filter-tabs">
                    <a href="<?php echo e(route('admin.index')); ?>"
                        class="filter-tab <?php echo e(empty($statusFilter) ? 'active' : ''); ?>">Semua</a>
                    <a href="?status=pending"
                        class="filter-tab <?php echo e($statusFilter === 'pending' ? 'active' : ''); ?>">Menunggu
                        Pembayaran</a>
                    <a href="?status=processing"
                        class="filter-tab <?php echo e($statusFilter === 'processing' ? 'active' : ''); ?>">Sedang
                        Diproses</a>
                    <a href="?status=shipped"
                        class="filter-tab <?php echo e($statusFilter === 'shipped' ? 'active' : ''); ?>">Dikirim</a>
                    <a href="?status=delivered"
                        class="filter-tab <?php echo e($statusFilter === 'delivered' ? 'active' : ''); ?>">Sampai</a>
                    <a href="?status=cancelled"
                        class="filter-tab <?php echo e($statusFilter === 'cancelled' ? 'active' : ''); ?>">Dibatalkan</a>
                </div>

                <form method="get" action="" class="search-box">
                    <input type="text" name="search" placeholder="Cari pesanan..."
                        value="<?php echo e(htmlspecialchars($searchTerm)); ?>">
                    <?php if (!empty($statusFilter)): ?>
                    <input type="hidden" name="status" value="<?php echo e(htmlspecialchars($statusFilter)); ?>">
                    <?php endif; ?>
                    <button type="submit"><i class="fas fa-search"></i> Cari</button>
                </form>
            </div>

            <!-- Orders Table -->
            <div class="orders-table">
                <?php if (count($orders) == 0): ?>
                <div class="empty-state">
                    <img src="image/empty-box.png" alt="No Orders">
                    <h3>Tidak ada pesanan ditemukan</h3>
                    <p>Belum ada pesanan yang sesuai dengan filter atau pencarian Anda.</p>
                </div>
                <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Produk</th>
                            <th>Pelanggan</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                     <!-- Replace the problematic table row section with this fixed version -->

<?php foreach ($orders as $order): ?>
<tr>
    <td>#<?php echo e($order->id); ?></td>
    <td>
        <?php if($order->item_order && count($order->item_order) > 0): ?>
            <?php $__currentLoopData = $order->item_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $product = json_decode($item->product);
                ?>
                <div class="product-info">
                    <img src="<?php echo e($product->image ?? 'default-image.jpg'); ?>" alt="<?php echo e($product->name ?? 'Product'); ?>"
                        class="product-image">
                    <div>
                        <div><?php echo e($product->name ?? 'Unknown Product'); ?></div>
                        <small>x<?php echo e($item->qty ?? 0); ?></small>
                    </div>
                </div>
                <?php if(!$loop->last): ?><br><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="product-info">
                <div>No items found</div>
            </div>
        <?php endif; ?>
    </td>
    <td>
        <div><?php echo e($order->name); ?></div>
        <small><?php echo e($order->email); ?></small>
    </td>
    <td>Rp<?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
    <td>
        <span class="status-badge status-<?php echo e($order->status); ?>">
            <?php
            $status_map = [
                'pending' => 'Menunggu Pembayaran',
                'processing' => 'Sedang Diproses',
                'shipped' => 'Dikirim',
                'delivered' => 'Sampai',
                'cancelled' => 'Dibatalkan',
            ];
            echo $status_map[$order->status] ?? 'Unknown Status';
            ?>
        </span>
    </td>
    <td><?php echo e(date('d M Y H:i', strtotime($order->created_at))); ?></td>
    <td>
        <button class="action-btn"
            onclick="openUpdateModal(<?php echo e($order->id); ?>, '<?php echo e($order->status); ?>')">
            <i class="fas fa-edit"></i> Update Status
        </button>
    </td>
</tr>
<?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Status Update Modal -->
    <div id="updateModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Update Status Pesanan</h2>
                <span class="close">&times;</span>
            </div>

            <form id="updateForm" method="post" action="<?php echo e(route('admin.update_status')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="order_id" name="order_id" value="">

                <div class="form-group">
                    <label for="status">Status Pesanan:</label>
                    <select id="status" name="status" required>
                        <option value="pending">Menunggu Pembayaran</option>
                        <option value="processing">Sedang Diproses</option>
                        <option value="shipped">Dikirim</option>
                        <option value="delivered">Sampai</option>
                        <option value="cancelled">Dibatalkan</option>
                    </select>
                </div>

                <div class="form-buttons">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
                    <button type="submit" name="update_status" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Modal functionality
        const modal = document.getElementById('updateModal');
        const span = document.getElementsByClassName('close')[0];

        function openUpdateModal(orderId, currentStatus) {
            document.getElementById('order_id').value = orderId;
            document.getElementById('status').value = currentStatus;
            modal.style.display = 'flex';
        }

        function closeModal() {
            modal.style.display = 'none';
        }

        span.onclick = closeModal;

        window.onclick = function(event) {
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>

</html>
<?php /**PATH C:\Users\andre\recyco\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>