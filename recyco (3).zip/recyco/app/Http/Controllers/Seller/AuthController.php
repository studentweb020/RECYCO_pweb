<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Seller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login()
    {
        return view('seller.login');
    }

    public function do_login(Request $request)
    {
        $credentials = $request->validate([
            'storename' => 'required|string',
            'phone' => 'required|numeric',
        ]);

        $seller = Seller::where('storename', $credentials['storename'])
            ->where('phone', $credentials['phone'])
            ->first();

        if ($seller) {
            Auth::guard('seller')->login($seller);
            return redirect()->route('seller.index');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }

    public function register()
    {
        return view('seller.register');
    }

    public function do_register(Request $request)
    {
        $request->validate([
            'storename' => 'required|string',
            'phone' => 'required|numeric',
            'location' => 'required|string',
            'address' => 'required|string'
        ]);

        $seller = Seller::create([
            'storename' => $request->storename,
            'phone' => $request->phone,
            'location' => $request->location,
            'address' => $request->address,
        ]);

        Auth::guard('seller')->login($seller);

        return redirect()->route('seller.index');
    }

    public function logout()
    {
        Auth::guard('seller')->logout();
        return redirect()->route('seller.login');
    }
}
