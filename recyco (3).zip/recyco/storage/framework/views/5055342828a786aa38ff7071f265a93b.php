<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Recyco - Jual Produk</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'recyco-green': '#10b981',
                        'recyco-green-dark': '#059669',
                    }
                }
            }
        }
    </script>
</head>

<body class="bg-gray-50 font-sans min-h-screen">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div class="flex justify-between items-center max-w-7xl mx-auto">
            <div class="flex items-center gap-2 text-xl font-bold text-gray-800">
                <span class="text-2xl">⚡</span>
                Recyco
            </div>
            <nav class="flex gap-4">
                <button class="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <span class="text-xl">🔔</span>
                </button>
                <button class="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <span class="text-xl">👤</span>
                </button>
            </nav>
        </div>
    </header>

    <!-- Main Container -->
    <div class="max-w-4xl mx-auto px-6 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-8 text-center">Jual Produk</h1>

        <!-- Display validation errors -->
        <?php if($errors->any()): ?>
            <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <div class="text-red-800">
                    <ul class="list-disc list-inside space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>

        <div class="hidden bg-red-50 border border-red-200 rounded-lg p-4 mb-6" id="errorAlert">
            <div class="text-red-800">
                <ul class="list-disc list-inside space-y-1" id="errorList">
                </ul>
            </div>
        </div>

        <!-- Form -->
        <form action="<?php echo e(route('seller.store_product')); ?>" method="POST" enctype="multipart/form-data" class="bg-white rounded-xl shadow-lg p-8" id="productForm">
            <?php echo csrf_field(); ?>
            <div class="grid lg:grid-cols-2 gap-8">
                <!-- Left Column - Form Fields -->
                <div class="space-y-6">
                    <div>
                        <input 
                            type="text" 
                            name="name" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-recyco-green focus:border-transparent outline-none transition-all placeholder-gray-500" 
                            placeholder="Enter Product Name" 
                            value="<?php echo e(old('name')); ?>"
                            required 
                        />
                    </div>
                    
                    <div>
                        <textarea 
                            name="description" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-recyco-green focus:border-transparent outline-none transition-all placeholder-gray-500 resize-vertical" 
                            placeholder="Enter Product Description" 
                            rows="4"
                        ><?php echo e(old('description')); ?></textarea>
                    </div>
                    
                    <div>
                        <input 
                            type="number" 
                            name="stock" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-recyco-green focus:border-transparent outline-none transition-all placeholder-gray-500"
                            placeholder="Enter the Amount of Product Stock" 
                            min="0" 
                            value="<?php echo e(old('stock')); ?>"
                            required 
                        />
                    </div>
                    
                    <div>
                        <input 
                            type="number" 
                            name="price" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-recyco-green focus:border-transparent outline-none transition-all placeholder-gray-500" 
                            placeholder="Enter Product Price" 
                            min="0" 
                            step="0.01" 
                            value="<?php echo e(old('price')); ?>"
                            required 
                        />
                    </div>
                </div>

                <!-- Right Column - Image Upload -->
                <div class="flex items-center justify-center">
                    <div 
                        class="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-recyco-green hover:bg-gray-50 transition-all group"
                        onclick="document.getElementById('imageInput').click()"
                    >
                        <div class="text-4xl text-gray-400 group-hover:text-recyco-green transition-colors mb-2">+</div>
                        <div class="text-gray-600 group-hover:text-recyco-green transition-colors text-center px-4" id="uploadText">
                            Click to upload product image
                        </div>
                        <input type="file" name="image" id="imageInput" accept="image/*" class="hidden" />
                    </div>
                </div>
            </div>

            <!-- Buttons -->
            <div class="flex flex-col sm:flex-row gap-4 justify-center mt-8">
                <button 
                    type="submit" 
                    class="bg-recyco-green hover:bg-recyco-green-dark text-white font-semibold px-8 py-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-recyco-green focus:ring-offset-2"
                >
                    Save
                </button>
                <button 
                    type="button" 
                    class="bg-gray-500 hover:bg-gray-600 text-white font-semibold px-8 py-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2" 
                    onclick="cancelForm()"
                >
                    Cancel
                </button>
            </div>
        </form>
    </div>

    <script>
        // Handle file input change
        document.getElementById('imageInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const uploadText = document.getElementById('uploadText');
            
            if (file) {
                uploadText.textContent = file.name;
            } else {
                uploadText.textContent = 'Click to upload product image';
            }
        });

        // Handle cancel button
        function cancelForm() {
            if (confirm('Apakah Anda yakin ingin membatalkan? Data yang sudah diisi akan hilang.')) {
                window.location.href = "<?php echo e(route('seller.index')); ?>";
            }
        }

        // Handle form submission
        document.getElementById('productForm').addEventListener('submit', function(e) {
            const requiredFields = ['name', 'stock', 'price'];
            let isValid = true;
            let errors = [];
            
            requiredFields.forEach(function(fieldName) {
                const field = document.querySelector(`[name="${fieldName}"]`);
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('border-red-500', 'focus:ring-red-500');
                    field.classList.remove('border-gray-300', 'focus:ring-recyco-green');
                    
                    // Add error message
                    const fieldLabel = {
                        'name': 'Product Name',
                        'stock': 'Stock',
                        'price': 'Price'
                    };
                    errors.push(`${fieldLabel[fieldName]} is required`);
                } else {
                    field.classList.remove('border-red-500', 'focus:ring-red-500');
                    field.classList.add('border-gray-300', 'focus:ring-recyco-green');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                
                // Show error alert
                const errorAlert = document.getElementById('errorAlert');
                const errorList = document.getElementById('errorList');
                
                errorList.innerHTML = '';
                errors.forEach(error => {
                    const li = document.createElement('li');
                    li.textContent = error;
                    errorList.appendChild(li);
                });
                
                errorAlert.classList.remove('hidden');
                
                // Scroll to top to show errors
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
                // Hide error alert if form is valid
                document.getElementById('errorAlert').classList.add('hidden');
            }
        });

        // Remove error styling when user starts typing
        document.querySelectorAll('input[required]').forEach(input => {
            input.addEventListener('input', function() {
                if (this.value.trim()) {
                    this.classList.remove('border-red-500', 'focus:ring-red-500');
                    this.classList.add('border-gray-300', 'focus:ring-recyco-green');
                }
            });
        });
    </script>
</body>

</html><?php /**PATH C:\Users\andre\recyco\resources\views/seller/add_product.blade.php ENDPATH**/ ?>