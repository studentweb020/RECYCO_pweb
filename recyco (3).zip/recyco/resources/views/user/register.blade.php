<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco - Create Account</title>
    <link rel="stylesheet" href="{{ asset('dist/style.css') }}">
</head>

<body>
    <div class="container">
        <div class="login-card">
            <h1 class="title">Sign Up for Recyco</h1>
            <p class="subtitle">Let's get started! Create your account to access all features.</p>

            @if ($errors->any())
                <div class="error-message">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form class="registration-form" method="POST" action="{{ route('do_register') }}">
                @csrf
                <div class="form-group">
                    <label for="username">User Name</label>
                    <input type="text" id="username" name="username" placeholder="Create your user name" required>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Please enter your email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password"
                        placeholder="Create your password (8+ characters)" required minlength="8">
                </div>

                <div class="form-group">
                    <label for="mother_name">Mother's Maiden Name (Security Question)</label>
                    <input type="text" id="mother_name" name="mother_name"
                        placeholder="Enter your mother's maiden name" required>
                    <small class="form-text">Ini akan digunakan untuk verifikasi jika Anda lupa password</small>
                </div>

                <div class="checkbox-group">
                    <input type="checkbox" id="terms" name="terms" class="checkbox-input" required>
                    <label for="terms" class="checkbox-label">
                        I agree with Recyco's <a href="#" class="terms-link">Terms of Service</a>,
                        <a href="#" class="terms-link">Privacy Policy</a>, and our default
                        <a href="#" class="terms-link">Notification Settings</a>.
                    </label>
                </div>

                <button type="submit" class="create-account-btn">Create Account</button>
            </form>

            <p class="signin-prompt">Already have an account? <a href="{{ route('login') }}" class="signin-link">Sign
                    In</a></p>
        </div>
    </div>
</body>

</html>
