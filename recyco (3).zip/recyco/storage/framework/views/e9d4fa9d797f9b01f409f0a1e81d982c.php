<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco - Sign In</title>
    <link rel="stylesheet" href="<?php echo e(asset('dist/style.css')); ?>">
</head>

<body>
    <div class="container">
        <div class="login-card">
            <h1 class="title">Sign In to Recyco</h1>
            <p class="subtitle">Welcome back! Please sign in to continue.</p>

            <?php if($errors->any()): ?>
                <div class="error-message">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('do_login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">User Name / Email Address</label>
                    <input type="text" id="email" name="email"
                        placeholder="Please enter your user name / email" required>
                </div>

                <div class="form-group password-group">
                    <label for="password">Password</label>
                    <a href="<?php echo e(route('forgot_password')); ?>" class="forgot-link">Forgot?</a>
                    <input type="password" id="password" name="password" placeholder="Please enter your password"
                        required>
                </div>

                <button type="submit" class="signin-btn">Sign In</button>
            </form>

            <p class="signup-prompt">Don't have an account? <a href="<?php echo e(route('register')); ?>" class="signup-link">Sign
                    Up</a>
            </p>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\andre\recyco\resources\views/user/login.blade.php ENDPATH**/ ?>