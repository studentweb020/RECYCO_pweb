<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up for Seller</title>
    <link rel="stylesheet" href="{{ asset('dist/seller.css') }}">
</head>

<body>
    <div class="signup-container">
        <div class="signup-form">
            <h1 class="signup-title">Sign Up for Seller</h1>
            <p class="signup-subtitle">Let's get started! Create your account to access all features.</p>

            <form action="{{ route('seller.do_register') }}" method="POST" class="signup-form-fields">
                @if ($errors->any())
                    <div class="error-message">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @csrf
                <div class="signup-field">
                    <label for="storename" class="signup-label">Store Name</label>
                    <input type="text" id="storename" name="storename" class="signup-input"
                        placeholder="Create your store name">
                </div>

                <div class="signup-field">
                    <label for="phone" class="signup-label">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="signup-input"
                        placeholder="Please enter your phone number">
                </div>

                <div class="signup-field">
                    <label for="location" class="signup-label">Location</label>
                    <input type="text" id="location" name="location" class="signup-input"
                        placeholder="Enter the province of the city regency">
                </div>

                <div class="signup-field">
                    <label for="address" class="signup-label">Full Address</label>
                    <input type="text" id="address" name="address" class="signup-input"
                        placeholder="Enter full address">
                </div>

                <button type="submit" class="signup-button">Register</button>
            </form>

            <p class="signup-footer">
                Have an account? <a href="{{ route('seller.login') }}" class="signup-link">Sign In</a>
            </p>
        </div>
    </div>
</body>

</html>
