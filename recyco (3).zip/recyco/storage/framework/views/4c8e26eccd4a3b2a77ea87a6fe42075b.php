<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semua Produk - Recyco</title>
    <link rel="stylesheet" href="<?php echo e(asset('dist/menu.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <style>
        /* Additional inline styles */
        a,
        a:hover,
        a:visited,
        a:active,
        a:focus {
            text-decoration: none !important;
            color: inherit;
        }

        .back-btn {
            background-color: #666;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #555;
            color: white;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <a href="/">
                <img src="<?php echo e(asset('dist/logo.png')); ?>" alt="Recyco" class="logo-image">
                <span>Recyco</span>
            </a>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Cari produk eco-friendly...">
        </div>
        <div class="nav-icons">
            <div class="icon">
                <a href="<?php echo e(route('notification')); ?>">
                    🔔
                </a>
            </div>
            <div class="icon">
                <a href="<?php echo e(route('cart.index')); ?>">
                    🛒
                </a>
            </div>
            <div class="icon">
                <a href="">
                    👤
                </a>
            </div>
        </div>
    </header>

    <div class="container">
        <a href="<?php echo e(route('market.index')); ?>" class="back-btn">← Kembali ke Market</a>
        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.product-list');

$__html = app('livewire')->mount($__name, $__params, 'lw-3309675930-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Recyco - Marketplace Produk Eco-friendly</p>
        </div>
    </footer>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
            integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
            crossorigin="anonymous" referreferrer="no-referrer"></script>
    <script>
        $(document).ready(function() {
            function saveCart(data) {
                localStorage.setItem('cart', JSON.stringify(data));
            }

            // Event delegation untuk tombol yang di-render ulang oleh Livewire
            $(document).on('click', '.btn-add-cart', function(e) {
                e.preventDefault();
                const product = $(this).data('product');
                product.qty = 1;
                var cart = JSON.parse(localStorage.getItem('cart') || '[]');

                const existing = cart.find(item => item.id === product.id);
                if (existing) {
                    existing.qty += 1;
                } else {
                    cart.push(product);
                }

                saveCart(cart);
                
                // Tampilkan notifikasi yang lebih menarik
                showNotification('Produk berhasil ditambahkan ke keranjang!', 'success');
            });

            // Fungsi untuk menampilkan notifikasi
            function showNotification(message, type = 'success') {
                const notification = $(`
                    <div class="custom-notification ${type}" style="
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        background: ${type === 'success' ? '#2e8b57' : '#dc3545'};
                        color: white;
                        padding: 15px 25px;
                        border-radius: 8px;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
                        z-index: 10000;
                        transform: translateX(100%);
                        transition: transform 0.3s ease;
                    ">
                        <span>${message}</span>
                        <button onclick="$(this).parent().fadeOut()" style="
                            background: none;
                            border: none;
                            color: white;
                            margin-left: 15px;
                            cursor: pointer;
                            font-size: 18px;
                        ">×</button>
                    </div>
                `);
                
                $('body').append(notification);
                
                // Animasi masuk
                setTimeout(() => {
                    notification.css('transform', 'translateX(0)');
                }, 100);
                
                // Auto hide setelah 3 detik
                setTimeout(() => {
                    notification.fadeOut(() => {
                        notification.remove();
                    });
                }, 3000);
            }
        });
    </script>
</body>

</html><?php /**PATH C:\Users\andre\recyco\resources\views/user/market/products.blade.php ENDPATH**/ ?>