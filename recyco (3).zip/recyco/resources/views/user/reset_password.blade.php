<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>
    <h1>Reset Password</h1>

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div style="color: green;">
            {{ session('success') }}
        </div>
    @endif

    <p>Token tidak valid atau telah kedaluwarsa. Silakan mulai ulang proses reset password.</p>
    <a href="{{ route('forgot_password') }}">Kembali ke Reset Password</a>
    <br>
    <a href="{{ route('login') }}">Ingat password Anda? Sign In</a>
</body>
</html>