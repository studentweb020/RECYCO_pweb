<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index()
    {
        // Data untuk navigation items
        $navItems = [
            ['name' => 'Home', 'link' => '/', 'icon' => '🏠'],
            ['name' => 'Market', 'link' => route('market.index'), 'icon' => '🛒'],
            ['name' => 'Orders', 'link' => route('order.index'), 'icon' => '📦'],
            ['name' => 'Cart', 'link' => route('cart.index'), 'icon' => '🛍️'],
        ];

        // Data kosong untuk products jika diperlukan
        $products = [];

        return view('user.notification', compact('navItems', 'products'));
    }
}