<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign In to Recyco</title>
    <link rel="stylesheet" href="{{ asset('dist/seller.css') }}" />
</head>

<body>
    <div class="signin-container">
        <div class="signin-form">
            <h1 class="signin-title">Sign In to Recyco</h1>
            <p class="signin-subtitle">Welcome back! Please sign in to continue.</p>

            <form action="{{ route('seller.do_login') }}" method="POST" class="signin-form-fields">
                @if ($errors->any())
                    <div class="error-message">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @csrf
                <div class="signin-field">
                    <label for="storename" class="signin-label">Store Name</label>
                    <input type="text" id="storename" name="storename" class="signin-input"
                        placeholder="Please enter your store name" />
                </div>
                <div class="signin-field">
                    <label for="phone" class="signin-label">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="signin-input"
                        placeholder="Please enter your phone" />
                </div>

                <button type="submit" class="signin-button">Login</button>
            </form>

            <p class="signin-footer">
                Don't have an account?
                <a href="{{ route('seller.register') }}" class="signin-link">Sign Up</a>
            </p>
        </div>
    </div>
</body>

</html>
