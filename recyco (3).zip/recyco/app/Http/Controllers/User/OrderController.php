<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with(['item_order.product'])->latest()->get();
        return view('user.order', [
            'orders' => $orders,
        ]);
    }

    public function update(Request $request, Order $order)
    {
        $request->validate([
            'address' => 'required|string|max:500',
            'payment_method' => 'required|string|max:255'
        ]);

        $order->update($request->only('address', 'payment_method'));

        return redirect()->route('order.index')
            ->with('success', 'Order updated successfully');
    }

    public function delete(Order $order)
    {
        $order->delete();

        return redirect()->route('order.index')
            ->with('success', 'Order deleted successfully');
    }

    public function cancel(Order $order)
    {
        try {
            $allowedStatuses = ['pending', 'processing'];

            if (!in_array($order->status, $allowedStatuses)) {
                return redirect()->back()->withErrors([
                    'error' => 'Pesanan tidak dapat dibatalkan (mungkin sudah dikirim/diterima)'
                ]);
            }

            $order->update(['status' => 'cancelled']);

            return redirect()->route('order.index')
                ->with('success', 'Pesanan berhasil dibatalkan');
        } catch (\Exception $e) {
            return redirect()->back()->withErrors([
                'error' => 'Error membatalkan pesanan: ' . $e->getMessage()
            ]);
        }
    }
}
