<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $searchTerm = $request->query('search', '');
        $period = $request->query('period', '');

        // Placeholder data (replace with actual query to orders table)
        $reports = [
            (object) [
                'date' => '2025-06-17',
                'total_orders' => 10,
                'revenue' => 5000000
            ],
            (object) [
                'date' => '2025-06-16',
                'total_orders' => 8,
                'revenue' => 4000000
            ],
            (object) [
                'date' => '2025-06-15',
                'total_orders' => 12,
                'revenue' => 6000000
            ],
        ];

        // Filter by period
        $filteredReports = array_filter($reports, function ($report) use ($period) {
            $reportDate = strtotime($report->date);
            $now = time();

            if ($period === 'weekly') {
                return $reportDate >= strtotime('-7 days', $now);
            } elseif ($period === 'monthly') {
                return $reportDate >= strtotime('-30 days', $now);
            }
            return true; // 'Semua' or no filter
        });

        // Filter by search term (search by date)
        if ($searchTerm) {
            $filteredReports = array_filter($filteredReports, function ($report) use ($searchTerm) {
                return stripos($report->date, $searchTerm) !== false;
            });
        }

        // Convert to array for view
        $reports = array_values($filteredReports);

        // Calculate total revenue
        $totalRevenue = array_sum(array_column($reports, 'revenue'));

        return view('admin.report', compact('reports', 'totalRevenue'));
    }
}