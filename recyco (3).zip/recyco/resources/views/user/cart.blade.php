<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco Cart</title>
    <link rel="stylesheet" href="{{ asset('dist/cart.css') }}">

    <style>
        *{
            font-family: arial;
        }
        .checkout-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
        }

        .product-section {
            flex: 1;
            min-width: 300px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .product-section:hover {
            transform: translateY(-5px);
        }

        .product-image-large {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .checkout-form {
            flex: 1;
            min-width: 300px;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            height: 100px;
            resize: vertical;
        }

        .price-section {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .price-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .total-price {
            font-size: 20px;
            font-weight: bold;
            color: #2e8b57;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
        }

        .btn-checkout {
            background-color: #2e8b57;
            color: white;
            border: none;
            padding: 12px 20px;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        .btn-checkout:hover {
            background-color: #3cb371;
        }

        .quantity-selector {
            display: flex;
            align-items: center;
            margin: 15px 0;
        }

        .quantity-btn {
            background: #f0f0f0;
            border: none;
            width: 30px;
            height: 30px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
            margin: 0 10px;
            height: 30px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        @media (max-width: 768px) {
            .checkout-container {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <header>
         <img src="{{ asset('dist/logo.png') }}" alt="Recyco" width="30px">
         <span>Recyco</span>
        <input type="text" placeholder="Keranjang saya" class="search-bar">
        <div class="icons">
            <span class="bell">🔔</span>
            <span class="cart">🛒</span>
            <span class="profile">👤</span>
        </div>
    </header>
    <form action="{{ route('cart.store') }}" method="POST" class="cart">
        <h2>Keranjang saya</h2>
        @if ($errors->any())
            <div class="error-message">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @csrf
        <div id="cart-data"></div>
        {{-- <div class="cart-item">
            <img src="https://via.placeholder.com/50" alt="Mini Handmade Quilling Basket">
            <div class="item-details">
                <h3>Keranjang Mini Handmade Quilling</h3>
                <p>Rp55.000</p>
                <div class="quantity">
                    <label>Jumlah</label>
                    <input type="number" value="1" min="1">
                </div>
                <button class="remove">Hapus</button>
            </div>
        </div> --}}
        <br>
        <div class="checkout-form">
            <h2>Informasi Pembelian</h2>

            <div class="form-group">
                <label for="name">Nama Lengkap:</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="address">Alamat Pengiriman:</label>
                <textarea id="address" name="address" required></textarea>
            </div>

            <div class="form-group">
                <label for="payment_method">Metode Pembayaran:</label>
                <select id="payment_method" name="payment_method" required>
                    <option value="">Pilih metode pembayaran</option>
                    <option value="bank_transfer">Transfer Bank</option>
                    <option value="credit_card">Kartu Kredit</option>
                    <option value="e_wallet">E-Wallet (OVO, GoPay, Dana)</option>
                    <option value="cod">COD (Bayar di Tempat)</option>
                </select>
            </div>

            <div class="form-group">
                <label for="notes">Catatan (Opsional):</label>
                <textarea id="notes" name="notes"></textarea>
            </div>

            <div class="price-section">
                <div class="price-row">
                    <span>Subtotal:</span>
                    <span id="subtotal">Rp<span id="priceTotal"></span></span>
                </div>
                <div class="price-row">
                    <span>Ongkos Kirim:</span>
                    <span>Rp15.000</span>
                </div>
                <div class="price-row total-price">
                    <span>Total Pembayaran:</span>
                    <span id="total-price">Rp<span id="priceTotalLast"></span></span>
                </div>
            </div>

            <button type="submit" class="btn-checkout">Proses Pembayaran</button>
            </d>

    </form>
</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {
        const cart = JSON.parse(localStorage.getItem('cart') || '[]');

        cart.forEach((item, index) => {
            $('#cart-data').append(`<div class="cart-item" data-id="${item.id}">
            <input type="hidden" name="product[${index}][id]" value="${item.id}" >
            <img src="${item.image}" alt="${item.name}">
            <div class="item-details">
                <h3>${item.name}</h3>
                <p>Rp${item.price.toLocaleString("id-ID")}</p>
                <div class="quantity">
                    <label>Jumlah</label>
                    <input type="number" name="product[${index}][qty]" class="qty-input" value="${item.qty}" min="1">
                </div>
                <button class="remove">Hapus</button>
            </div>
        </div>`);
        });

        function calculateTotal() {
            const cartList = JSON.parse(localStorage.getItem('cart') || '[]');
            const total = cartList.reduce((sum, item) => sum + (item.price * item.qty), 0);
            $('#priceTotal').text(total.toLocaleString("id-ID"));
            $('#priceTotalLast').text((total + 15000).toLocaleString("id-ID"));
        }

        calculateTotal();

        $(document).on('input', '.qty-input', function() {
            let newQty = parseInt($(this).val());
            const itemId = $(this).closest('.cart-item').data('id');

            if (isNaN(newQty) || newQty < 1) {
                newQty = 1;
            }

            let cartList = JSON.parse(localStorage.getItem('cart') || '[]');
            cartList = cartList.map(item => {
                if (item.id === itemId) {
                    item.qty = newQty;
                }
                return item;
            });

            localStorage.setItem('cart', JSON.stringify(cartList));
            calculateTotal();
        });

        $(document).on('click', '.remove', function() {
            const cartItem = $(this).closest('.cart-item');
            const itemId = cartItem.data('id');

            let cartList = JSON.parse(localStorage.getItem('cart') || '[]');
            cartList = cartList.filter(item => item.id !== itemId);

            localStorage.setItem('cart', JSON.stringify(cartList));
            cartItem.remove();

            calculateTotal();
        });
    });
</script>

</html>
