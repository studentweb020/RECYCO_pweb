<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tips - Recyco</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }

        .tips-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            min-height: 100vh;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        /* Header Styles */
        .tips-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: white;
            border-bottom: 1px solid #e0e0e0;
        }

        .tips-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .tips-logo-img {
            width: 30px;
            height: 30px;
        }

        .tips-brand {
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }

        .tips-nav {
            display: flex;
            gap: 15px;
        }

        .tips-icon-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .tips-icon-btn:hover {
            background-color: #f0f0f0;
        }

        .tips-bell,
        .tips-cart,
        .tips-profile {
            font-size: 18px;
        }

        /* Title Section */
        .tips-title-section {
            background: linear-gradient(135deg, #7dd3a0, #5bc97d);
            padding: 30px 25px;
            text-align: center;
        }

        .tips-title {
            color: white;
            font-size: 28px;
            font-weight: bold;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        /* Content */
        .tips-content {
            padding: 25px;
            background: #f8f9fa;
        }

        /* Main Article */
        .tips-main-article {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .tips-article-image {
            position: relative;
            height: 200px;
            background: linear-gradient(45deg, #8B4513, #D2691E);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .tips-image {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid white;
        }

        .tips-image-label {
            position: absolute;
            bottom: 15px;
            left: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.9);
            padding: 8px 12px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            color: #333;
            text-align: center;
        }

        .tips-article-content {
            padding: 25px;
        }

        .tips-article-title {
            font-size: 22px;
            font-weight: bold;
            color: #2d3748;
            margin-bottom: 15px;
            line-height: 1.3;
        }

        .tips-article-description {
            font-size: 14px;
            line-height: 1.6;
            color: #4a5568;
            text-align: justify;
        }

        /* Steps Section */
        .tips-steps-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .tips-steps-title {
            font-size: 20px;
            font-weight: bold;
            color: #7dd3a0;
            text-align: center;
            margin-bottom: 25px;
        }

        .tips-steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .tips-step-card {
            display: flex;
            gap: 15px;
            align-items: flex-start;
        }

        .tips-step-number {
            background: linear-gradient(135deg, #7dd3a0, #5bc97d);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
            flex-shrink: 0;
        }

        .tips-step-content {
            flex: 1;
        }

        .tips-step-title {
            font-size: 14px;
            font-weight: 600;
            color: #7dd3a0;
            margin-bottom: 10px;
            line-height: 1.4;
        }

        .tips-step-icon {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 60px;
        }

        .tips-step-image {
            width: 50px;
            height: 50px;
            object-fit: contain;
        }

        /* Custom Icons */
        .tips-magnifying-glass {
            position: relative;
            width: 50px;
            height: 50px;
        }

        .tips-glass-lens {
            width: 35px;
            height: 35px;
            border: 3px solid #ff8c42;
            border-radius: 50%;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 140, 66, 0.1);
        }

        .tips-glass-handle {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 15px;
            height: 15px;
            background: #ff8c42;
            transform: rotate(45deg);
            border-radius: 2px;
        }

        .tips-eye {
            font-size: 20px;
        }

        .tips-sun {
            position: relative;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .tips-sun-center {
            font-size: 30px;
            animation: tips-rotate 3s linear infinite;
        }

        .tips-blender {
            position: relative;
            width: 40px;
            height: 50px;
        }

        .tips-blender-base {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 15px;
            background: #4a5568;
            border-radius: 5px;
        }

        .tips-blender-jar {
            position: absolute;
            bottom: 15px;
            left: 50%;
            transform: translateX(-50%);
            width: 25px;
            height: 25px;
            background: linear-gradient(to bottom, transparent 0%, #e2e8f0 50%, #cbd5e0 100%);
            border: 2px solid #4a5568;
            border-radius: 5px;
        }

        .tips-blender-lid {
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 8px;
            background: #4a5568;
            border-radius: 3px;
        }

        @keyframes tips-rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* Responsive Design for Tips */
        @media (max-width: 768px) {
            .tips-container {
                max-width: 100%;
            }
            
            .tips-header {
                padding: 12px 20px;
            }
            
            .tips-title-section {
                padding: 25px 20px;
            }
            
            .tips-title {
                font-size: 24px;
            }
            
            .tips-content {
                padding: 20px;
            }
            
            .tips-article-content {
                padding: 20px;
            }
            
            .tips-article-title {
                font-size: 20px;
            }
            
            .tips-article-description {
                font-size: 13px;
            }
            
            .tips-steps-section {
                padding: 20px;
            }
            
            .tips-steps-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .tips-step-card {
                gap: 12px;
            }
            
            .tips-step-title {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <div class="tips-container">
        <!-- Header -->
        <header class="tips-header">
            <div class="tips-logo">
                 <img src="<?php echo e(asset('dist/logo.png')); ?>" alt="Recyco" class="tips-logo-img"> 
                <span class="tips-brand">Recyco</span>
            </div>
            <div class="tips-nav">
                <button class="tips-icon-btn">
                    <span class="tips-bell">🔔</span>
                </button>
                <button class="tips-icon-btn">
                    <span class="tips-cart">🛒</span>
                </button>
                <button class="tips-icon-btn">
                    <span class="tips-profile">👤</span>
                </button>
            </div>
        </header>

        <!-- Title Section -->
        <div class="tips-title-section">
            <h1 class="tips-title">Tips</h1>
        </div>

        <!-- Content -->
        <div class="tips-content">
            <!-- Main Article -->
            <article class="tips-main-article">
                <div class="tips-article-image">
                    <img src="<?php echo e(asset('dist/keranjangroti.jpg')); ?>" alt="Recyco" class="tips-image">
                    <div class="tips-image-label">
                        <span>Mengolah Makanan Sisa atau Roti Kering untuk Ternak</span>
                    </div>
                </div>
                <div class="tips-article-content">
                    <h2 class="tips-article-title">Makanan Sisa Jadi Berkah: Mengolah Roti Kering untuk Pakan Ternak</h2>
                    <p class="tips-article-description">
                        Daripada dibuang, makanan sisa dan roti kering bisa diubah jadi sumber gizi untuk ternak! Banyak peternak kini mulai memanfaatkan limbah makanan ini sebagai pakan alternatif yang hemat, bergizi, dan ramah lingkungan. Roti kering yang sudah tidak layak dikonsumsi manusia ternyata masih bisa dimanfaatkan sebagai pakan ternak, lho! Caranya pun cukup mudah dan bisa membantu mengurangi limbah makanan di rumah.
                    </p>
                </div>
            </article>

            <!-- Steps Section -->
            <div class="tips-steps-section">
                <h3 class="tips-steps-title">Langkah - Langkah</h3>
                
                <div class="tips-steps-grid">
                    <!-- Step 1 -->
                    <div class="tips-step-card">
                        <div class="tips-step-number">1.</div>
                        <div class="tips-step-content">
                            <h4 class="tips-step-title">Ambil roti kering sisa yang sudah tidak layak konsumsi.</h4>
                            <div class="tips-step-icon">
                               <img src="<?php echo e(asset('dist/keranjangroti.jpg')); ?>" alt="Recyco"  class="tips-step-image">
                            </div>
                        </div>
                    </div>

                    <!-- Step 2 -->
                    <div class="tips-step-card">
                        <div class="tips-step-number">2.</div>
                        <div class="tips-step-content">
                            <h4 class="tips-step-title">Pastikan bebas jamur.</h4>
                            <div class="tips-step-icon">
                                <div class="tips-magnifying-glass">
                                    <div class="tips-glass-handle"></div>
                                    <div class="tips-glass-lens">
                                        <div class="tips-eye">👁</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 3 -->
                    <div class="tips-step-card">
                        <div class="tips-step-number">3.</div>
                        <div class="tips-step-content">
                            <h4 class="tips-step-title">Jemur di bawah matahari biar makin awet.</h4>
                            <div class="tips-step-icon">
                                <div class="tips-sun">
                                    <div class="tips-sun-center">☀️</div>
                                    <div class="tips-sun-rays"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 4 -->
                    <div class="tips-step-card">
                        <div class="tips-step-number">4.</div>
                        <div class="tips-step-content">
                            <h4 class="tips-step-title">Blender sampai jadi remah halus.</h4>
                            <div class="tips-step-icon">
                                <div class="tips-blender">
                                    <div class="tips-blender-base"></div>
                                    <div class="tips-blender-jar"></div>
                                    <div class="tips-blender-lid"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\andre\recyco\resources\views/user/tips.blade.php ENDPATH**/ ?>