<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco Admin - Pengaturan</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid #3c546d;
        }

        .sidebar-header img {
            width: 40px;
            margin-right: 10px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
            color: white;
            text-decoration: none;
        }

        .menu-item.active {
            background-color: #3c546d;
            border-left: 4px solid #4CAF50;
        }

        .menu-item:hover {
            background-color: #3c546d;
            cursor: pointer;
        }

        .menu-item i {
            margin-right: 10px;
            font-size: 18px;
        }

        .admin-info {
            padding: 20px;
            border-top: 1px solid #3c546d;
            position: absolute;
            bottom: 20px;
            width: 100%;
        }

        .admin-name {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .logout-btn {
            color: #e74c3c;
            margin-top: 10px;
            display: inline-block;
            text-decoration: none;
        }

        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card h3 {
            font-size: 14px;
            color: #777;
            margin-bottom: 10px;
        }

        .stat-card .count {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }

        .stat-card.total {
            border-top: 3px solid #3498db;
        }

        .filters {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }

        .search-box {
            display: flex;
            gap: 10px;
        }

        .search-box input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 250px;
        }

        .search-box button {
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .orders-table {
            width: 100%;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #f5f5f5;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #555;
            border-bottom: 1px solid #ddd;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .empty-state {
            text-align: center;
            padding: 40px 0;
        }

        .empty-state img {
            width: 120px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: #555;
            margin-bottom: 10px;
        }

        .empty-state p {
            color: #777;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow: auto;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            border-radius: 8px;
            width: 400px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .close {
            font-size: 24px;
            cursor: pointer;
            color: #777;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 15px;
        }

        .form-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background-color: #4CAF50;
            color: white;
        }

        .btn-secondary {
            background-color: #ddd;
            color: #333;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
            text-align: center;
            display: inline-block;
        }

        .status-0 {
            background-color: #fff3e0;
            color: #ff9800;
        }

        .status-1 {
            background-color: #e8f5e9;
            color: #4caf50;
        }

        .status--1 {
            background-color: #ffebee;
            color: #f44336;
        }

        .action-btn {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            margin-right: 5px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="{{ asset('dist/logo.png') }}" alt="Recyco">
                <h2>Recyco Admin</h2>
            </div>
           <div class="sidebar-menu">
                <a href="{{ route('admin.index') }}" class="menu-item active" style="color: white; text-decoration: none;">
                    <i class="fas fa-shopping-bag"></i>
                    <span>Kelola Pesanan</span>
                </a>
                <a href="{{ route('admin.product.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-box"></i>
                    <span>Produk</span>
                </a>
                <a href="{{ route('admin.customer.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-users"></i>
                    <span>Pelanggan</span>
                </a>
                <a href="{{ route('admin.report.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-chart-bar"></i>
                    <span>Laporan</span>
                </a>
                <a href="{{ route('admin.settings.index') }}" class="menu-item" style="color: white; text-decoration: none;">
                    <i class="fas fa-cog"></i>
                    <span>Pengaturan</span>
                </a>
            </div>
            <div class="admin-info">
                <div class="admin-name">{{ Auth::guard('admin')->user()->username }}</div>
                <div class="admin-role">Administrator</div>
                <a href="{{ route('admin.logout') }}" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="page-header">
                <h1>Pengaturan</h1>
                <div class="date">{{ date('l, d F Y') }}</div>
            </div>

            @if (session('message'))
                <div class="alert alert-success">
                    {{ session('message') }}
                </div>
            @endif
            @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif

            <!-- Stats -->
            <div class="stats-container">
                <div class="stat-card total">
                    <h3>Terakhir Login</h3>
                    <div class="count">{{ Auth::guard('admin')->user()->last_login ?? 'Belum ada data' }}</div>
                </div>
            </div>

            <!-- Settings Form -->
            <div class="orders-table">
                <form method="POST" action="{{ route('admin.settings.update') }}">
                    @csrf
                    @method('PATCH')
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="{{ old('username', Auth::guard('admin')->user()->username) }}" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="{{ old('email', Auth::guard('admin')->user()->email) }}" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Kata Sandi Baru (kosongkan jika tidak ingin mengubah)</label>
                        <input type="password" id="password" name="password">
                    </div>
                    <div class="form-group">
                        <label for="password_confirmation">Konfirmasi Kata Sandi Baru</label>
                        <input type="password" id="password_confirmation" name="password_confirmation">
                    </div>
                    <div class="form-buttons">
                        <button type="button" class="btn btn-secondary" onclick="openUpdateModal()">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>

            <!-- Confirmation Modal -->
            <div id="updateModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Konfirmasi Perubahan</h2>
                        <span class="close">×</span>
                    </div>
                    <p>Apakah Anda yakin ingin membatalkan perubahan?</p>
                    <div class="form-buttons">
                        <button type="button" class="btn btn-secondary" onclick="closeModal()">Tidak</button>
                        <button type="button" class="btn btn-primary" onclick="window.location.reload()">Ya</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const modal = document.getElementById('updateModal');
        const span = document.getElementsByClassName('close')[0];

        function openUpdateModal() {
            modal.style.display = 'flex';
        }

        function closeModal() {
            modal.style.display = 'none';
        }

        span.onclick = closeModal;

        window.onclick = function(event) {
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>