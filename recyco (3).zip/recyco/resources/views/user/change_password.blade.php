<!DOCTYPE html>
<html>
<head>
    <title>Ubah Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background-color: #f4f7fa;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        a {
            color: green;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        a:hover {
            color: green;
            text-decoration: underline;
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: green;
        }

        p {
            font-size: 1rem;
            margin-bottom: 1rem;
        }

        form {
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin-bottom: 2rem;
        }

        div[style="color: green;"], div[style="color: green;"] {
            margin-bottom: 1.5rem;
            padding: 1rem;
            border-radius: 4px;
        }

        div[style="color: green;"] {
            background: #ffe6e6;
            border: 1px solid #ff4d4d;
        }

        div[style="color: green;"] {
            background: #e6ffe6;
            border: 1px solid #4dff4d;
        }

        ul {
            list-style: disc;
            margin-left: 1.5rem;
        }

        label {
            display: block;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }

        input[type="password"], input[type="text"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d9e6;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input[type="password"]:focus, input[type="text"]:focus {
            border-color: #007bff;
            outline: none;
        }

        small {
            display: block;
            font-size: 0.8rem;
            color: #6b7280;
            margin-top: 0.25rem;
        }

        .password-container {
            position: relative;
        }

        .password-container span {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #007bff;
            font-size: 0.9rem;
        }

        .password-container span:hover {
            color: #0056b3;
        }

        button {
            width: 100%;
            padding: 0.75rem;
            background: green;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-top: 1rem;
        }

        button:hover {
            background: green;
        }

        .links {
            text-align: center;
            font-size: 0.9rem;
        }

        .links a {
            margin: 0 0.5rem;
        }

        @media (max-width: 600px) {
            form {
                padding: 1.5rem;
            }

            h1 {
                font-size: 1.5rem;
            }

            body {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <a href="{{ route('index') }}">← Kembali ke Beranda</a>
    <h1>Ubah Password</h1>

    @if (Auth::check())
        <p>{{ Auth::user()->username }}</p>
        <p>{{ Auth::user()->email }}</p>
    @elseif ($email)
        <p>{{ $email }}</p>
    @endif

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div style="color: green;">
            {{ session('success') }}
        </div>
    @endif

    <p>Masukkan password saat ini dan password baru Anda</p>

    <form method="POST" action="{{ isset($token) ? route('do_reset_password', ['token' => $token]) : route('do_change_password') }}">
        @csrf

        @if (isset($token))
            <input type="hidden" name="token" value="{{ $token }}">
        @else
            <div class="password-container">
                <label for="current_password">Password Saat Ini</label>
                <input type="password" name="current_password" id="current_password" required>
                <span onclick="togglePassword('current_password')">Show</span>
            </div>
        @endif

        <div class="password-container">
            <label for="new_password">Password Baru</label>
            <input type="password" name="password" id="new_password" required>
            <span onclick="togglePassword('new_password')">Show</span>
            <small>Password harus minimal 8 karakter dan berbeda dari password saat ini</small>
        </div>

        <div class="password-container">
            <label for="confirm_password">Konfirmasi Password Baru</label>
            <input type="password" name="password_confirmation" id="confirm_password" required>
            <span onclick="togglePassword('confirm_password')">Show</span>
            <small>Masukkan ulang password baru untuk konfirmasi</small>
        </div>

        <button type="submit">Ubah Password</button>
    </form>

    <div class="links">
        <a href="{{ route('index') }}">Kembali ke Beranda</a>
        |
        @if (Auth::check())
            <a href="{{ route('logout') }}">Logout</a>
        @else
            <a href="{{ route('login') }}">Login</a>
        @endif
    </div>

    <script>
    function togglePassword(id) {
        const input = document.getElementById(id);
        input.type = input.type === 'password' ? 'text' : 'password';
    }
    </script>
</body>
</html>