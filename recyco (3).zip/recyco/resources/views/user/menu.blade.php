<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recyco - Marketplace Produk Eco-Friendly</title>
    <link rel="stylesheet" href="{{ asset('dist/menu.css') }}">
    <style>
        /* Additional inline styles to ensure no underlines anywhere */
        a,
        a:hover,
        a:visited,
        a:active,
        a:focus {
            text-decoration: none !important;
            color: inherit;
        }

        .nav-item a {
            text-decoration: none !important;
            color: inherit;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <a href="/">
                <img src="{{ asset('dist/logo.png') }}" alt="Recyco" class="logo-image">
                <span>Recyco</span>
            </a>
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Cari produk eco-friendly...">
        </div>
        <div class="nav-icons">
            <div class="icon">🔔</div>
            <a href=""div class="icon">🛒</div>
            <div class="icon">
                <a href="">
                    👤
                </a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="banner-section">
            <div class="promo-banner">
                <h3>Promo Spesial untuk Produk Pilihan!</h3>
                <p>Dapatkan menarik untuk produk eco-friendly favoritmu.</p>
                <p>➡️ Cek sekarang sebelum kehabisan!</p>
            </div>
            <div class="service-banner">
                <h3>Produk & Layanan Terbaik dari RECYCO!</h3>
                <p>Temukan solusi ramah lingkungan yang terpercaya hanya di recyco.</p>
                <p>🌿 Ikut andil selamatkan bumi!</p>
            </div>
        </div>


        <div class="nav-menu">
            <?php foreach ($navItems as $item): ?>
            <div class="nav-item">
                <a href="{{ $item['link'] }}">
                    <div class="nav-icon">{{ $item['icon'] }}</div>
                    <div>{{ $item['name'] }}</div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>


        <h3 class="section-title">Rekomendasi produk</h3>

        <div class="product-grid">
            <?php if (isset($products) && is_array($products)): ?>
            <?php foreach ($products as $product): ?>
            <div class="product-card">
                <a href="/checkout/{{ $product['id'] }}">
                    <div class="product-image">
                        <img src="{{ asset('dist/' . $product['image']) }}" alt="{{ $product['name'] }}">
                    </div>
                    <div class="product-info">
                        <h4>{{ $product['name'] }}</h4>
                        <p class="price">Rp{{ number_format($product['price'], 0, ',', '.') }}</p>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <p class="no-products">Tidak ada produk yang tersedia saat ini.</p>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2025 Recyco - Marketplace Produk Eco-friendly</p>
        </div>
    </footer>
</body>

</html>
